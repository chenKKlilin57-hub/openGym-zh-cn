// Keep the reviewed source separate from the official English catalogue and persistent data.
import { readFileSync, writeFileSync } from 'node:fs'
import { EXDB } from '../frontend/src/lib/exercises-data.js'
const source = JSON.parse(readFileSync(new URL('./exercise-name-sources/zh.json', import.meta.url), 'utf8'))
if (Object.keys(source).length !== EXDB.length) throw new Error('Chinese name source must cover exactly the built-in catalogue')
for (const e of EXDB) {
  if (!source[e.id]?.trim() || !/\p{Script=Han}/u.test(source[e.id]) || /[A-Za-z]/.test(source[e.id])) throw new Error('Missing Chinese name: ' + e.id)
}
writeFileSync(new URL('../frontend/src/exercise-names/zh.js', import.meta.url), '// Curated Simplified Chinese names. Regenerate with scripts/build-zh-exercise-names.mjs.\nexport default ' + JSON.stringify(source, null, 2) + '\n')
console.log('Chinese exercise names:', EXDB.length)
