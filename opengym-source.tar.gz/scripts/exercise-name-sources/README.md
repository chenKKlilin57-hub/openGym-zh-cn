# Brazilian Portuguese exercise names

`pt-BR.json` is the editable source for the Brazilian Portuguese exercise-name
pack. It maps every built-in EXDB exercise ID to a Portuguese title. The app
combines that title with the unchanged English source at runtime:

```text
Elevação assistida das pernas deitada (assisted lying leg raise)
```

Custom exercise names are never translated. IDs, plan data, workout history,
imports and exports continue to use the canonical catalogue entries.

Generate the runtime pack with:

```sh
node scripts/build-pt-br-exercise-names.mjs
```

The initial translations were produced from the English EXDB titles with LLM
assistance and must not be described as reviewed by a native speaker unless a
named human reviewer completes that review. They are original translations and
were not copied from another Portuguese exercise dataset.

---

# Russian exercise names

`ru.json` is the same thing for Russian, and `GLOSSARY.ru.md` beside it fixes
the terminology — which movements keep an English loanword a Russian lifter
actually says (`бёрпи`, `машина Смита`, `EZ-гриф`) and which get a Russian
term, so a batch translated next month matches one translated today.

```sh
node scripts/translate-ru-exercise-names.mjs --apply   # fills in what is missing
node scripts/build-ru-exercise-names.mjs               # regenerates the runtime pack
```

The translation script only visits IDs the source does not already have, so it
is safe to re-run after the catalogue grows, and it checkpoints after every
batch. Same caveat as above: these were produced with LLM assistance from the
English titles and must not be described as reviewed by a native speaker unless
a named human reviewer completes that review.

---

# German exercise names

`de.json` is the editable source for the German exercise-name pack, and it
covers a stage rather than the whole catalogue: 760 of the 1,324 built-in
exercises. Left out are the 325 whose equipment is `body weight`, and 239
equipment exercises whose German name is written but not yet signed off by a
native speaker (`AWAITING_REVIEW` in `scripts/de-name-rules.mjs` lists them,
with the reason). Both groups keep their English title — the app falls back
per exercise, so a partial pack costs nothing beyond the names it does not
yet carry. Which exercises the stage contains is enforced, not approximate:
`scripts/de-name-rules.mjs` defines the set, and the builder refuses a source
that misses one of them or adds an entry from outside it.

Clearing a name from `AWAITING_REVIEW` is what a second German-speaking
reviewer does: delete its id there, put its name in `de.json`, rebuild. The
test fails if the two ever disagree, so the list cannot quietly rot.

`de-CH` ships no pack of its own. It derives this one by replacing ß with ss,
so German names are written with ß here and the Swiss spelling follows
automatically.

Generate the runtime pack with:

```sh
node scripts/build-de-exercise-names.mjs
```

Translate a stage — one equipment family at a time, dry run first, `--apply`
to write:

```sh
node scripts/translate-de-exercise-names.mjs --equipment='trap bar'
node scripts/translate-de-exercise-names.mjs --equipment=dumbbell --limit=999 --apply
```

`--limit` caps how many names one invocation translates and defaults to 40, so a run
without it stops early and still exits successfully — pass a limit at least as large as
the family you are translating. Names already in `de.json` are skipped, so re-running
after an interrupt costs nothing.

Equipment and identity-changing qualifiers (assisted, weighted, one-arm,
seated, incline …) are checked against `scripts/de-name-rules.mjs` while the
batch is still in hand: a violation goes back to the model as a correction
naming the offending word, and a batch that cannot be fixed is never written.
The same rules run again in `frontend/src/lib/de-exercise-names.test.js`, so
CI fails on anything edited in by hand afterwards.

The translations were produced from the English EXDB titles with LLM
assistance and then reviewed by a native German speaker, who went through the
pack against the English titles: 405 of the 760 shipped names were accepted
individually and 2 were corrected by hand. The remaining 353 were not read one
by one — they contain none of the terms the review left open, which is the
criterion that put the other 239 equipment names in `AWAITING_REVIEW` instead
of in the pack. So the pack is native-reviewed in the sense stated here and no
further: a second reviewer is still worth having. They are original
translations and were not copied from another German exercise dataset.
