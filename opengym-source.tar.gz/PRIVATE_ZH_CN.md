# openGym 中文私人版 v0.1

> 当前常用地址 localhost:8080 已切换为 Supabase 云端版；本页记录的是保留的 v0.1 文件版。云端启动、存储和备份请看 [云端版说明](</Users/Zhuanz/Documents/Playground 2/openGym-cloud/private/cloud/README.md>)。原版正式服务已停止，数据已备份，8081 原版演示保留。

> 当前云端版已经补齐全部内置动作名称的中文，并验收界面和动作说明；下文“动作名称沿用官方英文”仅描述历史文件演示版。详见 [中文验收记录](private/CHINESE_COVERAGE.md)。

基于官方稳定版 **v1.3.9**（2026-09-28），Tag `v1.3.9`，上游 Commit `e6c920eb0a657e57139798f60da40c934aec9301`。本地分支：`zh-cn-v0.1`。先验证未经修改的官方版本，再完成中文调整。

## 当前使用方法

这台 Mac 已安装依赖、下载官方媒体并完成构建。正式环境和演示环境均已启动。

```sh
cd '/Users/Zhuanz/Documents/Playground 2/openGym'
python3 private/local.py start
python3 private/local.py status
python3 private/local.py stop
```

正式地址：<http://localhost:8080>。首次使用请创建自己的个人资料；正式数据库尚无账号或训练记录。启用的是官方密码登录选项，也保留官方通行密钥登录。登录后，训练数据同步到本机服务器；未登录的访客模式已关闭。

演示地址：<http://localhost:8081>。用户名 **数据库验证**，测试密码 **GymDemo-Only-2026!R7q9**。其中有“数据库测试”和“胸部训练”，包含卧推 60/50 kg × 10、9、8；动作名称沿用官方英文。演示启停命令加 `--demo`，例如 `python3 private/local.py stop --demo`。

服务由 macOS `launchctl` 管理，关闭终端或结束此聊天不会停止服务；进程退出后会自动重启。尚未设置开机登录自动启动，重启电脑后执行 `start` 即可。运行配置与日志在 `.private-runtime/private/` 和 `.private-runtime/demo/`，均不进入 Git。

## 数据、备份与恢复

| 环境 | 实际目录 | 容器 Volume |
| --- | --- | --- |
| 正式 | `/Users/Zhuanz/Documents/Playground 2/openGym/data` | 当前本机运行，无 Volume |
| 演示 | `/Users/Zhuanz/Documents/Playground 2/opengym-demo-data` | 当前本机运行，无 Volume |

后端采用官方 JSON 文件存储，没有 SQL、ORM 或独立迁移命令。`db.json` 保存账号和认证信息；`state-<用户ID>.json` 保存该账号的训练计划、训练、体重和设置；`secret` 是会话密钥，`vapid.json` 是推送密钥，`uploads/` 保存自定义动作媒体。首次创建账号时才生成 `db.json`。保留整个数据目录，不能只备份训练 JSON。官方读写采用临时文件加原子重命名；旧数据兼容通过原有字段默认值/载入逻辑完成，本次不改变结构。

前端 `localStorage` 中的 `gym_state_v1` 是本地镜像，登录账号的服务器文件才是本次持久化验证的依据。不同端口的正式/演示客户端与服务器数据均隔离。

正式环境备份（短暂停机，保证快照一致）：

```sh
python3 private/local.py stop
python3 private/local.py backup
python3 private/local.py start
```

备份输出在仓库 `backups/`，文件名以 `opengym-private-` 开头，权限为 `0600`。请另存到你自己的备份介质；同一磁盘上的快照不能防止磁盘损坏。备份包含整个服务器数据目录，排除演示专用 `test-login.json`；不包含可重新下载的官方动作媒体或依赖。

恢复正式备份：将下面的路径替换为实际输出的 **private** 备份文件。

```sh
python3 private/local.py stop
python3 private/local.py restore --archive '/绝对路径/opengym-private-时间戳.tar.gz'
python3 private/local.py start
```

恢复前的现有目录会保留为 `data.before-restore-时间戳`，便于回退。演示备份/恢复的每条命令都加 `--demo`；不要将演示备份恢复到正式环境。

已实际验证演示备份：`backups/opengym-demo-20261004-231927-582315.tar.gz`。停止、备份、恢复、启动后，账号、两次训练、组数/重量/次数、中文备注及会话密钥均正常；再次修改训练备注也写回了服务器。

## 重新安装与构建

官方容器使用 Node 22。本机运行 Node 24.15.0，完整前端测试另用 Node 22 验证。需要 Node、npm、Python 3.12+ 和 macOS `launchctl`。

```sh
cd api
npm ci --omit=optional
cd ../frontend
npm ci
cd ..
cp .env.example .env
```

在 `.env` 中加入以下官方配置选项。本机已有配置，无需覆盖。

```dotenv
DEFAULT_LANG=zh-CN
ALLOW_GUEST=0
PASSWORD_LOGIN=1
COACH_DISABLED=1
```

已有媒体授权时，沿用官方获取脚本：

```sh
bash scripts/fetch-media.sh
python3 private/local.py build
python3 private/local.py start
```

修改前端后，执行 `build`，刷新页面即可；修改 `.env` 后应 `stop` 再 `start`。本机脚本固定正式端口 8080/3000/8888，演示端口 8081/3001/8889，并设置匹配的官方 Origin/RP_ID。前端和媒体服务监听本机回环地址；API 保持官方监听方式。这是本机私人使用入口，尚未验证公网、反向代理或手机跨设备部署。

## Docker 方案

本机没有 Docker，未执行容器构建、重建或 Docker 重启测试。保留官方三服务架构：一次性媒体下载、Node API、nginx 前端。以下覆写只选择本地中文版构建镜像及版本标记：

```sh
docker compose -f docker-compose.yml -f private/compose.zh-cn.yml up -d --build
docker compose -f docker-compose.yml -f private/compose.zh-cn.yml down
```

切换到 Docker 前先停止本机正式服务，避免端口和数据写入冲突。官方 `./data:/data` 是宿主机目录绑定，不是命名 Volume；正常 `down` 不删除宿主机数据。容器方案备份时先 `down`，再使用上述 `backup`/`restore`，完成后重新 `up`。这些容器命令尚未实测。

## 中文与修改范围

现有 `zh` 语言包已经表示简体中文，日期格式为 `zh-CN`；继续使用原有 i18n，无需另建框架。现有 1703 个 UI 文本键，加设置页 3 个版权说明文本键，共 1706 个；中文包无缺失，插值占位符一致。优化“训练计划”“个人资料”“历史记录”“数据统计”“训练容量”“正式组”等术语。

主要修改：`frontend/src/locales/zh.js`、`frontend/src/views/Settings.jsx`；其余 15 个语言包补齐三个设置页英文键以保持官方校验一致。新增 `private/local.py`、`private/compose.zh-cn.yml`、`private/check-zh.mjs` 和交付文档；`.gitignore` 排除本地配置、备份和截图。

未修改布局、样式、业务逻辑、API、数据库结构、认证体系、依赖或锁文件。官方 AI Coach 通过已有选项关闭。`LICENSE`、`NOTICE.md` 及原作者/数据来源署名保持完整。媒体从官方指定上游下载到被忽略的 `media/img`、`media/gif`，不提交或重新分发。截图也不进入 Git。

动作库共 **1324** 条，来源是 hasaneyldrm/exercises-dataset；`frontend/src/lib/exercises-data.js` 保存 `id`、英文 `n`、部位 `bp`、器械 `eq`、目标肌肉 `tg`、次要肌群 `sm`、步骤 `st`、媒体文件名 `img/gif`。例如卧推 ID `0025`，图片/GIF 使用同 ID 加原有文件后缀。ID 与关联未变；肌群、器械和动作说明沿用现有中文支持，名称仍为英文。

后续如完整翻译动作名称，应增加 `frontend/src/exercise-names/zh.js` 的 ID → 中文名称映射，并在 `frontend/src/lib/i18n-core.js` 的 `EXERCISE_NAME_LANGS` 中登记 `zh`；原有 `exerciseNameFor`、搜索和动态加载会使用该映射，无需改正式数据库。当前未生成批量机器翻译名称。保留 kg、lb、RPE、RIR、PR、1RM、产品/来源名称等通用缩写或专有名词。

测试细节与未验证项见 [private/TEST_RESULTS.md](private/TEST_RESULTS.md)。
