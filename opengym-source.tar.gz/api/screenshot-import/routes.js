import { ScreenshotImportError, validateScreenshotRequest, reserveScreenshotUsage } from './service.js';

export function screenshotRoutes({ service, json, readBody, readSession, withRegistry, registry, saveDb, address, now = Date.now }) {
  const authenticate = req => {
    const user = readSession(req);
    if (!user) throw new ScreenshotImportError(401, 'screenshot_auth', 'not signed in');
    return user.id;
  };
  return {
    'POST /api/plan-import/screenshots': async (req, res) => {
      let release;
      const controller = new AbortController();
      const departed = () => { if (!res.writableEnded) controller.abort(); };
      res.once?.('close', departed);
      try {
        // Both checks refresh the registry. Never retain a mutable user record outside its turn.
        const uid = await withRegistry(() => authenticate(req));
        service.checkRequest(address(req));
        const images = validateScreenshotRequest(await readBody(req));
        if (controller.signal.aborted) return;
        release = service.acquire(uid);
        const reserved = await withRegistry(async () => {
          if (authenticate(req) !== uid) throw new ScreenshotImportError(401, 'screenshot_auth', 'not signed in');
          if (controller.signal.aborted) return false;
          const db = registry(), previous = db.screenshotImportUsage;
          reserveScreenshotUsage(db, uid, service.config, now());
          try { await saveDb(); }
          catch (e) {
            if (previous === undefined) delete db.screenshotImportUsage;
            else db.screenshotImportUsage = previous;
            throw e;
          }
          return true;
        });
        if (!reserved || controller.signal.aborted) return;
        const result = await service.recognize(images, controller.signal);
        await withRegistry(() => {
          if (authenticate(req) !== uid) throw new ScreenshotImportError(401, 'screenshot_auth', 'not signed in');
          if (!controller.signal.aborted) json(res, 200, result);
        });
      } catch (e) {
        if (controller.signal.aborted) return;
        if (!(e instanceof ScreenshotImportError)) throw e;
        json(res, e.status, { error: e.message, code: e.code, ...(e.retryAfter ? { retryAfter: e.retryAfter } : {}) },
          e.retryAfter ? { 'Retry-After': String(e.retryAfter) } : undefined);
      } finally { release?.(); res.off?.('close', departed); }
    },
  };
}
