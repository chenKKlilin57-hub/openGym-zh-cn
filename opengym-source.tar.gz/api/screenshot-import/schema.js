// Shared, runtime-independent boundary for untrusted screenshot recognition output.
// It contains no account, history, catalogue IDs, provider credentials, or store access.
export const SCREENSHOT_LIMITS = Object.freeze({ images: 3, imageBytes: 1024 * 1024, routines: 14, exercises: 100 })

const record = x => !!x && typeof x === 'object' && !Array.isArray(x)
const invalid = () => { throw new Error('截图识别结果格式不正确，请换一张清晰的训练截图重试。') }

function text(value, max, required = false) {
  if (value == null && !required) return ''
  if (typeof value !== 'string' || value.length > max) invalid()
  const out = value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim()
  if (required && !out) invalid()
  return out
}

function number(value, min, max, integer = false) {
  if (value == null) return null
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) invalid()
  return value
}

function warnings(value) {
  if (value == null) return []
  if (!Array.isArray(value) || value.length > 12) invalid()
  return [...new Set(value.map(v => text(v, 200, true)))]
}

export function normalizeScreenshotDraft(raw) {
  if (!record(raw) || raw.version !== 1 || !['plan', 'history', 'unknown'].includes(raw.kind)
    || !Array.isArray(raw.routines) || !raw.routines.length || raw.routines.length > SCREENSHOT_LIMITS.routines) invalid()
  let count = 0
  const routines = raw.routines.map(r => {
    if (!record(r) || !Array.isArray(r.exercises) || !r.exercises.length || r.exercises.length > 30) invalid()
    count += r.exercises.length
    if (count > SCREENSHOT_LIMITS.exercises) invalid()
    return {
      name: text(r.name, 120, true),
      day: number(r.day, 0, 6, true),
      exercises: r.exercises.map(e => {
        if (!record(e) || (e.unit != null && !['kg', 'lb'].includes(e.unit))
          || (e.mode != null && !['reps', 'time', 'cardio'].includes(e.mode))) invalid()
        const repsMin = number(e.repsMin, 1, 200, true)
        const repsMax = number(e.repsMax, 1, 200, true)
        if (repsMin != null && repsMax != null && repsMin > repsMax) invalid()
        return {
          name: text(e.name, 120, true),
          sets: number(e.sets, 1, 30, true),
          reps: number(e.reps, 1, 200, true),
          repsMin, repsMax,
          weight: number(e.weight, 0, 4000),
          unit: e.unit ?? null,
          mode: e.mode || 'reps',
          seconds: number(e.seconds, 1, 36000, true),
          minutes: number(e.minutes, 1, 600),
          restSeconds: number(e.restSeconds, 0, 3600, true),
          source: text(e.source, 600),
          note: text(e.note, 800),
          warnings: warnings(e.warnings)
        }
      })
    }
  })
  return { version: 1, kind: raw.kind, name: text(raw.name, 120) || '截图导入的训练计划', warnings: warnings(raw.warnings), routines }
}
