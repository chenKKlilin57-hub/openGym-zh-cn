// Server-only Supabase persistence. No browser key, SDK, or filesystem fallback.
import { AsyncLocalStorage } from 'node:async_hooks';

export class CloudStorageError extends Error {
  constructor(code = 'cloud-unavailable') {
    super('cloud storage unavailable');
    this.code = code;
  }
}

export class SupabaseStore {
  #url; #headers; #fetch; #instance; #revision = 0;
  #states = new Map(); #tail = Promise.resolve(); #context = new AsyncLocalStorage(); #pending = 0;

  constructor({ url, key, instance = 'main', fetchImpl = globalThis.fetch, allowLocal = false }) {
    let parsed;
    try { parsed = new URL(url); } catch { throw new Error('SUPABASE_URL is required'); }
    const local = allowLocal && ['localhost', '127.0.0.1', '[::1]'].includes(parsed.hostname);
    if ((!local && parsed.protocol !== 'https:') || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash) {
      throw new Error('SUPABASE_URL must be an HTTPS project origin');
    }
    let legacy = false;
    try { legacy = JSON.parse(Buffer.from(String(key).split('.')[1], 'base64url')).role === 'service_role'; } catch {}
    if (!String(key || '').startsWith('sb_secret_') && !legacy) throw new Error('A server-only Supabase secret/service_role key is required');
    if (!/^[A-Za-z0-9_-]{1,96}$/.test(instance)) throw new Error('Invalid SUPABASE_INSTANCE');
    this.#url = parsed.origin + '/rest/v1/';
    this.#headers = { apikey: key, 'Content-Type': 'application/json', ...(legacy ? { Authorization: `Bearer ${key}` } : {}) };
    this.#fetch = fetchImpl;
    this.#instance = instance;
  }

  async #request(route, { method = 'GET', body } = {}) {
    let response;
    try {
      response = await this.#fetch(this.#url + route, { method, headers: this.#headers,
        ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(10000) });
    } catch { throw new CloudStorageError(); }
    // Do not expose remote response bodies, URLs or credentials in logs/errors.
    if (!response.ok) throw new CloudStorageError();
    try { return await response.json(); } catch { throw new CloudStorageError(); }
  }

  rpc(name, args = {}) {
    return this.#request('rpc/' + name, { method: 'POST', body: { p_instance: this.#instance, ...args } });
  }

  async initialize(secret, vapid) {
    const row = await this.rpc('opengym_initialize', { p_secret: secret, p_vapid: vapid });
    if (!row || !/^[a-f0-9]{64}$/.test(row.session_secret) || !row.vapid?.publicKey || !row.vapid?.privateKey) throw new CloudStorageError();
    this.#revision = row.revision;
    return row;
  }

  async loadRegistry() {
    const rows = await this.#request('opengym_instances?instance_id=eq.' + encodeURIComponent(this.#instance) + '&select=registry,revision');
    const row = rows?.[0];
    if (!row || !Array.isArray(row.registry?.users) || !Array.isArray(row.registry?.creds)) throw new CloudStorageError();
    this.#revision = row.revision;
    return row.registry;
  }

  async saveRegistry(registry) {
    const result = await this.rpc('opengym_save_registry', { p_registry: registry, p_revision: this.#revision });
    if (!result?.ok) throw new CloudStorageError('cloud-conflict');
    this.#revision = result.revision;
    const retained = new Set(registry.users.map(u => u.id));
    for (const id of this.#states.keys()) if (!retained.has(id)) this.#states.delete(id);
  }

  async loadState(uid) {
    if (!/^[A-Za-z0-9_-]{1,128}$/.test(uid)) throw new Error('Invalid user ID');
    const rows = await this.#request('opengym_profiles?instance_id=eq.' + encodeURIComponent(this.#instance)
      + '&user_id=eq.' + encodeURIComponent(uid) + '&select=state');
    const state = rows?.[0]?.state || null;
    this.#states.set(uid, state);
    return state;
  }

  cachedState(uid) { return this.#states.get(uid) || null; }
  inExclusive() { return this.#context.getStore()?.active === true; }

  async writeState(uid, state, baseRev) {
    const result = await this.rpc('opengym_write_profile', { p_uid: uid, p_state: state, p_base_rev: baseRev ?? null });
    if (!result || typeof result.ok !== 'boolean' || !Number.isSafeInteger(result.rev)) throw new CloudStorageError();
    this.#states.set(uid, result.state);
    return result;
  }

  // The upstream authentication registry is one document. Serialize its handlers while
  // leaving the file backend's timing unchanged. Reentrant calls use a live scope token;
  // timers inherited from a finished handler must acquire a new turn.
  async exclusive(fn) {
    if (this.#context.getStore()?.active) return fn();
    if (this.#pending >= 128) throw new CloudStorageError('cloud-busy');
    this.#pending++;
    const previous = this.#tail;
    let release;
    this.#tail = new Promise(resolve => { release = resolve; });
    await previous;
    const token = { active: true };
    try { return await this.#context.run(token, fn); }
    finally { token.active = false; this.#states.clear(); this.#pending--; release(); }
  }
}

export function cloudStoreFromEnv(env = process.env) {
  const backend = env.DATA_BACKEND || 'file';
  if (backend === 'file') return null;
  if (backend !== 'supabase') throw new Error('DATA_BACKEND must be file or supabase');
  if (!/^(1|true|yes|on)$/i.test(env.COACH_DISABLED || '')) throw new Error('Supabase mode requires COACH_DISABLED=1; optional Coach files have not been migrated');
  return new SupabaseStore({ url: env.SUPABASE_URL, key: env.SUPABASE_SECRET_KEY || env.SUPABASE_SERVICE_ROLE_KEY,
    instance: env.SUPABASE_INSTANCE || 'main', allowLocal: env.NODE_ENV === 'test' });
}
