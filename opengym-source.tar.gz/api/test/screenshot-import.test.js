import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createScreenshotService, screenshotConfig, validateScreenshotRequest, reserveScreenshotUsage, ScreenshotImportError, SCREENSHOT_ROUTE } from '../screenshot-import/service.js';
import { screenshotRoutes } from '../screenshot-import/routes.js';

const config = () => screenshotConfig({ PLAN_IMPORT_ENABLED: '1', DEEPSEEK_API_KEY: 'test-only-not-a-real-key' });
const png = (width = 20, height = 30, size = 33) => {
  const b = Buffer.alloc(size);
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(b);
  b.writeUInt32BE(13, 8); b.write('IHDR', 12); b.writeUInt32BE(width, 16); b.writeUInt32BE(height, 20);
  return b;
};
const request = (b = png(), mime = 'image/png') => ({ consent: true, images: [{ dataUrl: `data:${mime};base64,${b.toString('base64')}` }] });
const draft = () => ({ version: 1, kind: 'plan', name: '测试计划', warnings: [], routines: [{ name: '胸部训练', day: null,
  exercises: [{ name: '杠铃卧推', sets: 3, reps: 8, weight: 40, unit: 'kg', mode: 'reps', id: 'must-not-be-trusted' }] }] });
const reply = (raw = draft(), reason = 'stop') => new Response(JSON.stringify({ choices: [{ finish_reason: reason, message: { content: JSON.stringify(raw) } }] }), { headers: { 'content-type': 'application/json' } });
const code = wanted => e => e instanceof ScreenshotImportError && e.code === wanted;

test('public config contains only declared caps, with bounded environment overrides', () => {
  const s = createScreenshotService({ config: config() });
  assert.deepEqual(s.publicConfig(), { enabled: true, provider: 'DeepSeek', max_images: 3, max_image_bytes: 1048576, daily_user_limit: 5 });
  assert.equal(screenshotConfig({ PLAN_IMPORT_ENABLED: '1' }).enabled, false);
  assert.equal(screenshotConfig({ DEEPSEEK_API_KEY: 'test' }).enabled, false);
  const c = screenshotConfig({ PLAN_IMPORT_DAILY_USER_LIMIT: '21', PLAN_IMPORT_DAILY_SITE_LIMIT: '0' });
  assert.equal(c.dailyUserLimit, 5); assert.equal(c.dailySiteLimit, 50);
});

test('valid PNG, JPEG and WebP headers are accepted; spoofed magic, sizes and inputs are refused', () => {
  const jpeg = Buffer.from([255,216,255,192,0,17,8,0,2,0,3,3,1,17,0,2,17,0,3,17,0,255,217]);
  const webp = Buffer.alloc(30); webp.write('RIFF'); webp.writeUInt32LE(22, 4); webp.write('WEBP', 8); webp.write('VP8X', 12); webp.writeUInt32LE(10, 16);
  for (const [b, mime] of [[png(), 'image/png'], [jpeg, 'image/jpeg'], [webp, 'image/webp']]) assert.equal(validateScreenshotRequest(request(b, mime)).length, 1);
  const invalid = [request(png(), 'image/jpeg'), request(png(0)), request(png(8193)), request(Buffer.from('<html>')),
    { ...request(), model: 'anything' }, { ...request(), key: 'anything' }, { ...request(), consent: false },
    { consent: true, images: [{ dataUrl: 'https://example.invalid/image.png' }] },
    { consent: true, images: [{ dataUrl: 'data:image/png;base64,a===' }] },
    { ...request(), images: Array(4).fill(request().images[0]) }, { ...request(), images: [] }];
  for (const body of invalid) assert.throws(() => validateScreenshotRequest(body), ScreenshotImportError);
  assert.throws(() => validateScreenshotRequest(request(png(20, 20, 1048577))), code('screenshot_too_large'));
  assert.equal(validateScreenshotRequest({ consent: true, images: Array(3).fill(request(png(20, 20, 1048576)).images[0]) }).length, 3);
});

test('usage is reserved per user/site, rolls over at Beijing midnight and has a retry time', () => {
  const db = {}, c = { ...config(), dailyUserLimit: 1, dailySiteLimit: 2 };
  const before = Date.parse('2026-10-05T15:59:59Z');
  reserveScreenshotUsage(db, 'one', c, before);
  assert.equal(db.screenshotImportUsage.day, '2026-10-05');
  assert.throws(() => reserveScreenshotUsage(db, 'one', c, before), e => code('screenshot_daily_limit')(e) && e.retryAfter === 1);
  reserveScreenshotUsage(db, 'two', c, before);
  assert.throws(() => reserveScreenshotUsage(db, 'three', c, before), code('screenshot_daily_limit'));
  reserveScreenshotUsage(db, 'one', c, before + 1000);
  assert.deepEqual(db.screenshotImportUsage, { day: '2026-10-06', total: 1, users: { one: 1 } });
});

test('same-day corrupt allowance fails closed, while a new day starts fresh', () => {
  const now = Date.parse('2026-10-05T00:00:00Z');
  for (const usage of [{ total: '1', users: { one: 1 } }, { total: 1, users: { one: -1 } },
    { total: 0, users: { one: 1 } }, { total: 1, users: null }, { total: NaN, users: {} }]) {
    const db = { screenshotImportUsage: { day: '2026-10-05', ...usage } };
    assert.throws(() => reserveScreenshotUsage(db, 'one', config(), now), code('screenshot_quota_unavailable'));
    reserveScreenshotUsage(db, 'one', config(), now + 86400000);
    assert.equal(db.screenshotImportUsage.total, 1);
  }
});

test('one fixed non-thinking JSON vision call normalizes the draft and never trusts AI IDs', async () => {
  let calls = 0;
  const s = createScreenshotService({ config: config(), fetchImpl: async (url, init) => {
    calls++;
    assert.equal(url, 'https://api.deepseek.com/chat/completions');
    const body = JSON.parse(init.body);
    assert.equal(body.model, 'deepseek-flash'); assert.deepEqual(body.thinking, { type: 'disabled' });
    assert.deepEqual(body.response_format, { type: 'json_object' });
    assert.equal(body.messages[1].content[1].type, 'image_url');
    return reply();
  } });
  const result = await s.recognize(validateScreenshotRequest(request()));
  assert.equal(calls, 1); assert.equal(result.draft.routines[0].exercises[0].weight, 40);
  assert.equal('id' in result.draft.routines[0].exercises[0], false);
  assert.equal(JSON.stringify(result).includes(config().key), false);
});

test('provider failures, invalid responses and truncation are safe and never retried', async () => {
  for (const response of [() => new Response('SECRET provider detail', { status: 401 }),
    () => new Response('not JSON'), () => reply(draft(), 'length'), () => reply({ version: 1, kind: 'unknown', routines: [] })]) {
    let calls = 0;
    const s = createScreenshotService({ config: config(), fetchImpl: async () => { calls++; return response(); } });
    await assert.rejects(s.recognize(request().images), e => e instanceof ScreenshotImportError && !e.message.includes('SECRET'));
    assert.equal(calls, 1);
  }
  const failed = createScreenshotService({ config: config(), fetchImpl: async () => { throw new Error('SECRET request body and key'); } });
  await assert.rejects(failed.recognize(request().images), e => code('screenshot_provider')(e) && !e.message.includes('SECRET'));
});

test('45-second deadline mechanism bounds both fetch and response-body reads', async () => {
  for (const fetchImpl of [async () => new Promise(() => {}), async () => ({ ok: true, headers: new Headers(), text: () => new Promise(() => {}) })]) {
    const s = createScreenshotService({ config: config(), fetchImpl, timeoutMs: 20 });
    await assert.rejects(s.recognize(request().images), code('screenshot_timeout'));
  }
});

test('per-user/global in-flight limits and independent IP bursts release cleanly', () => {
  const s = createScreenshotService({ config: config(), ipBurst: 2 });
  const first = s.acquire('one', 'ip-one');
  assert.throws(() => s.acquire('one', 'ip-two'), code('screenshot_busy'));
  const second = s.acquire('two', 'ip-two');
  assert.throws(() => s.acquire('three', 'ip-three'), code('screenshot_busy'));
  first(); second();
  const next = s.acquire('one', 'ip-one'); next();
  assert.throws(() => s.acquire('one', 'ip-one'), code('screenshot_rate_limit'));
});

function harness({ signedIn = true, saveFails = false, fetchImpl, readBody, limits = {} } = {}) {
  const db = { users: [{ id: 'one' }], untouchedTraining: { workouts: ['unchanged'] } };
  let calls = 0, saves = 0, turns = 0;
  const service = createScreenshotService({ config: { ...config(), ...limits }, fetchImpl: async (...args) => { calls++; return fetchImpl ? fetchImpl(...args) : reply(); } });
  const h = { signedIn, db, calls: () => calls, saves: () => saves, turns: () => turns };
  const routes = screenshotRoutes({ service,
    json: (res, status, body, headers) => Object.assign(res, { status, body, headers }),
    readBody: readBody || (async req => req.body), readSession: req => h.signedIn ? { id: req.uid || 'one' } : null,
    withRegistry: async fn => { turns++; return fn(); }, registry: () => db,
    saveDb: async () => { saves++; if (saveFails) throw new Error('CAS failed'); }, address: () => 'test-ip', now: () => Date.parse('2026-10-05T00:00:00Z'),
  });
  h.call = async (body = request(), uid = 'one', res = new EventEmitter()) => { await routes[SCREENSHOT_ROUTE]({ body, uid }, res); return res; };
  return h;
}

test('route authenticates before reading, saves allowance before calling and does not write training', async () => {
  const h = harness(); const old = structuredClone(h.db.untouchedTraining);
  const res = await h.call();
  assert.equal(res.status, 200); assert.equal(h.turns(), 3); assert.equal(h.saves(), 1); assert.equal(h.calls(), 1);
  assert.deepEqual(h.db.screenshotImportUsage, { day: '2026-10-05', total: 1, users: { one: 1 } });
  assert.deepEqual(h.db.untouchedTraining, old);
  const notSignedIn = harness({ signedIn: false });
  assert.equal((await notSignedIn.call()).status, 401); assert.equal(notSignedIn.calls(), 0); assert.equal(notSignedIn.saves(), 0);
});

test('invalid images, failed CAS and exhausted persisted quota make no provider call', async () => {
  const bad = harness(); assert.equal((await bad.call({ ...request(), model: 'other' })).status, 400);
  assert.equal(bad.calls(), 0); assert.equal(bad.saves(), 0);
  const failed = harness({ saveFails: true }); await assert.rejects(failed.call(), /CAS failed/);
  assert.equal(failed.calls(), 0); assert.equal(failed.db.screenshotImportUsage, undefined);
  const limited = harness({ limits: { dailyUserLimit: 1 } });
  assert.equal((await limited.call()).status, 200); assert.equal((await limited.call()).status, 429);
  assert.equal(limited.calls(), 1); assert.equal(limited.saves(), 1);
  const broken = harness(); broken.db.screenshotImportUsage = { day: '2026-10-05', total: 0, users: { one: 5 } };
  assert.equal((await broken.call()).status, 503); assert.equal(broken.calls(), 0); assert.equal(broken.saves(), 0);
  const unavailable = harness({ limits: { enabled: false }, readBody: () => { throw new Error('must not read'); } });
  assert.equal((await unavailable.call()).status, 503); assert.equal(unavailable.calls(), 0);
});

test('a session revoked while the provider is running cannot receive the draft', async () => {
  let finish, started;
  const ready = new Promise(resolve => { started = resolve; });
  const h = harness({ fetchImpl: () => { started(); return new Promise(resolve => { finish = resolve; }); } });
  const pending = h.call(); await ready; h.signedIn = false; finish(reply());
  assert.equal((await pending).status, 401);
});

test('slow bodies do not occupy provider slots; a body cancelled before validation spends no quota', async () => {
  let releaseBodies;
  const waiting = new Promise(resolve => { releaseBodies = resolve; });
  const h = harness({ readBody: req => req.body.slow ? waiting.then(() => request()) : Promise.resolve(req.body) });
  const cancelled = new EventEmitter();
  const pending = h.call({ slow: true }, 'slow-one', cancelled);
  const another = h.call({ slow: true }, 'slow-two');
  const result = await h.call(request(), 'ready');
  assert.equal(result.status, 200, 'ready images can run while two upload bodies are waiting');
  cancelled.emit('close'); releaseBodies();
  await Promise.all([pending, another]);
  assert.equal(h.calls(), 2); assert.equal(h.db.screenshotImportUsage.users['slow-one'], undefined);
  assert.equal(h.db.screenshotImportUsage.users.ready, 1);
});
