import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SupabaseStore, CloudStorageError, cloudStoreFromEnv } from '../supabase-store.js';

const options = { url: 'https://example.supabase.co', key: 'sb_secret_test_only', instance: 'test' };

test('cloud configuration refuses browser keys, insecure URLs and accidental fallback', () => {
  assert.equal(cloudStoreFromEnv({}), null);
  assert.throws(() => cloudStoreFromEnv({ DATA_BACKEND: 'unknown' }));
  assert.throws(() => new SupabaseStore({ ...options, key: 'sb_publishable_test' }));
  assert.throws(() => new SupabaseStore({ ...options, url: 'http://example.supabase.co' }));
  assert.throws(() => new SupabaseStore({ ...options, url: 'https://user:password@example.supabase.co' }));
  assert.throws(() => new SupabaseStore({ ...options, instance: 'test&other=main' }));
  assert.throws(() => cloudStoreFromEnv({ DATA_BACKEND: 'supabase', ...options }));
});

test('modern secret key uses apikey only; remote errors reveal no secret or response body', async () => {
  let seen;
  const store = new SupabaseStore({ ...options, fetchImpl: async (url, init) => {
    seen = { url, init };
    return new Response('private diagnostic sb_secret_do_not_log', { status: 503 });
  } });
  await assert.rejects(store.loadRegistry(), e => e instanceof CloudStorageError && !e.message.includes('secret'));
  assert.equal(seen.init.headers.apikey, options.key);
  assert.equal(seen.init.headers.Authorization, undefined);
  assert.equal(seen.url.includes(options.key), false);
});

test('failed writes never update cached state or pretend to succeed', async () => {
  const replies = [new Response(JSON.stringify([{ state: { _rev: 1, workouts: [{ id: 'old' }] } }])), new Response('{}', { status: 503 })];
  const store = new SupabaseStore({ ...options, fetchImpl: async () => replies.shift() });
  await store.loadState('u1');
  await assert.rejects(store.writeState('u1', { workouts: [{ id: 'new' }] }, 1));
  assert.equal(store.cachedState('u1').workouts[0].id, 'old');
});

test('exclusive handlers serialize, recover after failure, and allow nested work', async () => {
  const store = new SupabaseStore(options);
  const events = [];
  await Promise.allSettled([
    store.exclusive(async () => { events.push('one'); await store.exclusive(() => events.push('nested')); throw new Error('test'); }),
    store.exclusive(() => events.push('two'))
  ]);
  assert.deepEqual(events, ['one', 'nested', 'two']);
  assert.equal(store.inExclusive(), false);
});

test('state conflicts refresh the cache with the committed remote document', async () => {
  const remote = { ok: false, rev: 8, state: { _rev: 8, workouts: [{ id: 'remote' }] } };
  const store = new SupabaseStore({ ...options, fetchImpl: async () => new Response(JSON.stringify(remote)) });
  assert.deepEqual(await store.writeState('u1', { workouts: [] }, 7), remote);
  assert.equal(store.cachedState('u1')._rev, 8);
});
