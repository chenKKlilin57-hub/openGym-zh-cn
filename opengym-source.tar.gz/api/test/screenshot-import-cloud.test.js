import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { boundPort } from './helpers.mjs';

const API = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const secret = 'a'.repeat(64);
const payload = `tester:${Date.now() + 86400000}:0`;
const token = payload + '.' + crypto.createHmac('sha256', secret).update(payload).digest('base64url');
const headers = { Cookie: '__Host-gymsid=' + token, 'Content-Type': 'application/json', Origin: 'https://screenshot-test.invalid' };
const png = Buffer.alloc(33);
Buffer.from([137,80,78,71,13,10,26,10]).copy(png); png.writeUInt32BE(13, 8); png.write('IHDR', 12); png.writeUInt32BE(20, 16); png.writeUInt32BE(30, 20);
const body = JSON.stringify({ consent: true, images: [{ dataUrl: 'data:image/png;base64,' + png.toString('base64') }] });
const result = { version: 1, kind: 'plan', name: '测试', routines: [{ name: '训练', exercises: [{ name: '卧推', sets: 3, reps: 10 }] }] };

test('cloud screenshot recognition releases the registry turn and keeps quota across restart', { timeout: 30000 }, async t => {
  let registry = { users: [{ id: 'tester', name: 'Test', sv: 0 }], creds: [], subs: [], invites: [] }, revision = 1;
  let registrySaves = 0, profileWrites = 0, providerCalls = 0, providerRelease, providerStart;
  const providerStarted = new Promise(resolve => { providerStart = resolve; });
  const supabase = http.createServer(async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    let incoming = '';
    for await (const chunk of req) incoming += chunk;
    const data = incoming ? JSON.parse(incoming) : {};
    if (req.url === '/rest/v1/rpc/opengym_initialize') return res.end(JSON.stringify({ session_secret: secret, vapid: data.p_vapid, registry, revision }));
    if (req.url.startsWith('/rest/v1/opengym_instances?')) return res.end(JSON.stringify([{ registry, revision }]));
    if (req.url === '/rest/v1/rpc/opengym_save_registry') {
      assert.equal(data.p_revision, revision);
      registry = data.p_registry; revision++; registrySaves++;
      return res.end(JSON.stringify({ ok: true, revision }));
    }
    if (req.url.startsWith('/rest/v1/opengym_profiles?')) return res.end(JSON.stringify([{ state: { unit: 'kg', routines: [], workouts: [], _rev: 7 } }]));
    if (req.url === '/rest/v1/rpc/opengym_write_profile') profileWrites++;
    res.writeHead(404).end('{}');
  });
  const provider = http.createServer(async (req, res) => {
    providerCalls++;
    let incoming = ''; for await (const chunk of req) incoming += chunk;
    const data = JSON.parse(incoming);
    assert.equal(data.model, 'deepseek-flash');
    providerRelease = () => res.end(JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify(result) } }] }));
    providerStart();
  });
  await Promise.all([new Promise(resolve => supabase.listen(0, '127.0.0.1', resolve)), new Promise(resolve => provider.listen(0, '127.0.0.1', resolve))]);
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'gym-screenshot-cloud-'));
  const preload = path.join(directory, 'fake-provider.mjs');
  // Only a test child redirects the fixed provider URL. No production override or real key.
  fs.writeFileSync(preload, `const original = globalThis.fetch; globalThis.fetch = (url, init) => original(String(url) === 'https://api.deepseek.com/chat/completions' ? 'http://127.0.0.1:${provider.address().port}/chat' : url, init);`);
  const children = [];
  t.after(async () => {
    providerRelease?.();
    for (const child of children) if (child.exitCode === null && child.signalCode === null) child.kill('SIGKILL');
    supabase.closeAllConnections(); provider.closeAllConnections();
    await Promise.all([new Promise(resolve => supabase.close(resolve)), new Promise(resolve => provider.close(resolve))]);
    fs.rmSync(directory, { recursive: true, force: true });
  });
  const start = async () => {
    const child = spawn(process.execPath, ['--import', pathToFileURL(preload).href, 'server.js'], {
      cwd: API, stdio: ['ignore', 'pipe', 'pipe'],
      // Never inherit deployment configuration or a real provider/cloud credential.
      env: { PATH: process.env.PATH, NODE_ENV: 'test', PORT: '0', API_HOST: '127.0.0.1', DATA_DIR: directory,
        DATA_BACKEND: 'supabase', SUPABASE_URL: `http://127.0.0.1:${supabase.address().port}`,
        SUPABASE_SECRET_KEY: 'sb_secret_screenshot_test_only', SUPABASE_INSTANCE: 'screenshot-test',
        ORIGIN: 'https://screenshot-test.invalid', RP_ID: 'screenshot-test.invalid', COACH_DISABLED: '1',
        MEDIA_UPLOADS: '0', PASSWORD_LOGIN: '0', PLAN_IMPORT_ENABLED: '1', DEEPSEEK_API_KEY: 'test-only', PLAN_IMPORT_DAILY_USER_LIMIT: '1' },
    });
    children.push(child); let log = ''; child.stdout.on('data', d => log += d); child.stderr.on('data', d => log += d);
    return { child, url: `http://127.0.0.1:${await boundPort(child, () => log)}` };
  };
  const first = await start();
  const request = fetch(first.url + '/api/plan-import/screenshots', { method: 'POST', headers, body, signal: AbortSignal.timeout(10000) });
  request.catch(() => {});
  await providerStarted;
  // All of these would queue behind the provider if dispatch kept the full route in exclusive.
  const [config, rev, health] = await Promise.all([
    fetch(first.url + '/api/config', { signal: AbortSignal.timeout(2000) }),
    fetch(first.url + '/api/data/rev', { headers, signal: AbortSignal.timeout(2000) }),
    fetch(first.url + '/api/health', { signal: AbortSignal.timeout(2000) }),
  ]);
  assert.equal(config.status, 200); assert.equal(rev.status, 200); assert.equal(health.status, 200);
  assert.equal((await config.json()).screenshot_import.enabled, true); assert.equal((await rev.json()).rev, 7);
  assert.equal(registry.screenshotImportUsage.users.tester, 1); assert.equal(registrySaves, 1);
  providerRelease(); providerRelease = null;
  const completed = await request; assert.equal(completed.status, 200); assert.equal((await completed.json()).draft.kind, 'plan');
  assert.equal(profileWrites, 0);
  await new Promise(resolve => { first.child.once('exit', resolve); first.child.kill('SIGKILL'); });
  const second = await start();
  const repeated = await fetch(second.url + '/api/plan-import/screenshots', { method: 'POST', headers, body });
  assert.equal(repeated.status, 429); assert.equal((await repeated.json()).code, 'screenshot_daily_limit');
  assert.equal(providerCalls, 1, 'persisted allowance must survive a new API process');
  assert.equal(profileWrites, 0);
  const forged = await fetch(second.url + '/api/plan-import/screenshots', { method: 'POST', headers: { ...headers, Origin: 'https://hostile.invalid' }, body });
  assert.equal(forged.status, 403); assert.equal(providerCalls, 1);
  const anonymous = await fetch(second.url + '/api/plan-import/screenshots', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
  assert.equal(anonymous.status, 401); assert.equal(providerCalls, 1);
});
