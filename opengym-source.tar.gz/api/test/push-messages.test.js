import test from 'node:test';
import assert from 'node:assert/strict';
import { dayReminderPush, restTimerPush, testPush } from '../push-messages.js';

test('localizes every server-generated notification in pt-BR', () => {
  assert.deepEqual(restTimerPush('pt-BR'), {
    title: 'Descanso terminado 💪',
    body: 'Hora da próxima série.',
    tag: 'rest-timer',
  });
  assert.deepEqual(testPush('pt-BR'), {
    title: '要猛！',
    body: 'Notificação de teste ✅ — é assim que os alertas aparecem.',
    tag: 'test',
  });
  assert.deepEqual(dayReminderPush('pt-BR', { name: 'Treino A', emoji: '💪' }), {
    title: '💪 Treino A hoje',
    body: 'Está no seu plano — vamos treinar 💪',
    tag: 'day-reminder',
  });
});

test('localizes every server-generated notification in Chinese while retaining user routine names', () => {
  assert.deepEqual(restTimerPush('zh'), {
    title: '休息结束 💪',
    body: '开始下一组训练吧。',
    tag: 'rest-timer',
  });
  assert.deepEqual(testPush('zh'), {
    title: '要猛！',
    body: '测试通知 ✅——训练提醒会这样显示。',
    tag: 'test',
  });
  assert.deepEqual(dayReminderPush('zh', { name: 'openGym Bench A', emoji: '💪' }), {
    title: '💪 openGym Bench A 今天',
    body: '今天的训练已安排，出发吧 💪',
    tag: 'day-reminder',
  });
  assert.equal(dayReminderPush('zh', null).title, '今天有训练计划');
});

test('keeps the existing English copy as the fallback', () => {
  assert.deepEqual(restTimerPush('fr'), restTimerPush('en'));
  assert.equal(dayReminderPush('unknown', null).title, 'Workout planned today');
  assert.equal(testPush(undefined).body, 'Test notification ✅ — this is what alerts look like.');
});
