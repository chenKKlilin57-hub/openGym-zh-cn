import { useEffect, useRef, useState } from 'react'
import { useStore } from '../store/useStore.js'
import { useUI } from '../store/useUI.js'
import { api } from '../lib/api.js'
import { t, exerciseNameFor } from '../lib/i18n.js'
import { uiError } from '../lib/ui-error.js'
import { EXIDX, BODYPARTS } from '../lib/exercises.js'
import { mergePlan } from '../lib/plan-share.js'
import { createScreenshotReview, findScreenshotCandidates, buildScreenshotPlanBundle } from '../lib/screenshot-plan.js'
import { prepareScreenshot, SCREENSHOT_COUNT_MAX } from '../lib/screenshot-image.js'
import { useSheetKeyboard } from '../lib/use-sheet-keyboard.js'
import { Button, NumberField, TextField } from './ui.jsx'

export const screenshotPlanImportSheet = () => useUI.getState().openSheet(close => <ScreenshotPlanImport close={close} />)

function Numeric({ label, value, onChange, decimal = false }) {
  const ref = useRef(null)
  const focus = useSheetKeyboard(ref)
  // NumberField does not forward refs: the label finds its one input for the keyboard hook.
  return <label className="screenshot-field" ref={node => { ref.current = node?.querySelector('input') || null }}><span>{label}</span><NumberField aria-label={label} value={value} nullable decimal={decimal} onFocus={e => { e.target.select(); focus(e) }} onChange={onChange} /></label>
}

function DraftTextField(props) {
  const ref = useRef(null)
  const focus = useSheetKeyboard(ref)
  return <TextField ref={ref} onFocus={focus} {...props} />
}

function ExerciseDraft({ exercise, customEx, onChange, onRemove }) {
  const [query, setQuery] = useState(exercise.name || '')
  const [choosing, setChoosing] = useState(!exercise.matchId && !exercise.custom)
  const selected = EXIDX[exercise.matchId] || customEx.find(e => e.id === exercise.matchId)
  const candidates = choosing ? findScreenshotCandidates(query, customEx).slice(0, 8) : []
  const patch = values => onChange({ ...exercise, ...values })
  const select = candidate => {
    patch({ matchId: candidate.id, custom: false })
    setChoosing(false)
  }
  const weightUnit = exercise.unit || ''
  return <div className="screenshot-exercise">
    <div className="row between" style={{ gap: 8 }}>
      <b className="grow">{exercise.name}</b>
      <Button size="sm" variant="ghost" icon="trash" aria-label={t('Remove this exercise')} onClick={onRemove} />
    </div>
    {exercise.source && <div className="small dim screenshot-source">{t('Recognized text')}: {exercise.source}</div>}
    {exercise.note && <div className="small dim screenshot-source">{exercise.note}</div>}
    {(exercise.warnings || []).map((warning, i) => <div className="small screenshot-warning" key={i}>{warning}</div>)}
    <div className="small screenshot-match">
      {exercise.custom ? t('Will be added as a custom exercise') : selected ? t('Matched exercise: {0}', exerciseNameFor(selected)) : t('Choose the matching exercise before importing')}
    </div>
    <Button size="sm" variant="tinted" onClick={() => setChoosing(v => !v)}>{choosing ? t('Hide exercise search') : t('Change matched exercise')}</Button>
    {choosing && <div style={{ marginTop: 8 }}>
      <DraftTextField aria-label={t('Search matching exercises')} placeholder={t('Search matching exercises')} value={query} onChange={e => setQuery(e.target.value)} />
      <div className="screenshot-candidates">
        {candidates.map(candidate => <button type="button" key={candidate.id} onClick={() => select(candidate)}>
          <b>{exerciseNameFor(EXIDX[candidate.id] || candidate)}</b>
          <span className="small dim">{t(candidate.eq || '')} · {t(candidate.bp || '')}</span>
        </button>)}
        {!candidates.length && <div className="small dim">{t('No matching exercises found')}</div>}
      </div>
      <label className="screenshot-check"><input type="checkbox" checked={!!exercise.custom} onChange={e => patch({ custom: e.target.checked, matchId: e.target.checked ? null : exercise.matchId })} /><span>{t('Add as a custom exercise')}</span></label>
    </div>}
    {exercise.custom && <div className="screenshot-fields">
      <label className="screenshot-field"><span>{t('Exercise name')}</span><DraftTextField aria-label={t('Exercise name')} value={exercise.name} onChange={e => patch({ name: e.target.value })} /></label>
      <label className="screenshot-field"><span>{t('Choose a body part')}</span><select className="field" aria-label={t('Choose a body part')} value={exercise.customBodyPart || ''} onChange={e => patch({ customBodyPart: e.target.value })}>
        <option value="">{t('Choose a body part')}</option>{BODYPARTS.map(bp => <option key={bp} value={bp}>{t(bp)}</option>)}
      </select></label>
    </div>}
    <div className="screenshot-fields">
      <Numeric label={t('Working sets')} value={exercise.sets} onChange={sets => patch({ sets })} />
      <label className="screenshot-field"><span>{t('Exercise mode')}</span><select className="field" aria-label={t('Exercise mode')} value={exercise.mode || 'reps'} onChange={e => patch({ mode: e.target.value, ...(e.target.value === 'cardio' ? { weight: null, unit: null } : {}) })}>
        <option value="reps">{t('Repetitions')}</option><option value="time">{t('Seconds per set')}</option><option value="cardio">{t('Minutes per set')}</option>
      </select></label>
      {(!exercise.mode || exercise.mode === 'reps') && <>
        <Numeric label={t('Target repetitions')} value={exercise.reps} onChange={reps => patch({ reps, repsMin: null, repsMax: null })} />
        <Numeric label={t('Repetition range from (optional)')} value={exercise.repsMin} onChange={repsMin => patch({ repsMin, reps: null })} />
        <Numeric label={t('Repetition range to (optional)')} value={exercise.repsMax} onChange={repsMax => patch({ repsMax, reps: null })} />
      </>}
      {exercise.mode === 'time' && <Numeric label={t('Seconds per set')} value={exercise.seconds} onChange={seconds => patch({ seconds })} />}
      {exercise.mode === 'cardio' && <Numeric label={t('Minutes per set')} value={exercise.minutes} decimal onChange={minutes => patch({ minutes })} />}
      {exercise.mode !== 'cardio' && <>
      <Numeric label={t('Target weight (optional)')} value={exercise.weight} decimal onChange={weight => patch({ weight })} />
      <label className="screenshot-field"><span>{t('Weight unit')}</span><select className="field" aria-label={t('Weight unit')} value={weightUnit} onChange={e => patch({ unit: e.target.value || null })}>
        <option value="">{t('Not shown in screenshot')}</option><option value="kg">{t('Kilograms (kg)')}</option><option value="lb">{t('Pounds (lb)')}</option>
      </select></label>
      </>}
      <Numeric label={t('Rest seconds (optional)')} value={exercise.restSeconds} onChange={restSeconds => patch({ restSeconds })} />
    </div>
  </div>
}

export default function ScreenshotPlanImport({ close }) {
  const customEx = useStore(s => s.S.customEx || [])
  const user = useStore(s => s.user)
  const [loading, setLoading] = useState(true)
  const [config, setConfig] = useState(null)
  const [images, setImages] = useState([])
  const [consent, setConsent] = useState(false)
  const [busy, setBusy] = useState(false)
  const [review, setReview] = useState(null)
  const [allowHistory, setAllowHistory] = useState(false)
  const [error, setError] = useState('')
  const alive = useRef(true), busyLock = useRef(false), applied = useRef(false), input = useRef(null), nextKey = useRef(0), owner = useRef(user?.id)
  useEffect(() => {
    // A sign-out or account switch cannot carry another account's private draft into a save.
    if (owner.current !== user?.id) { alive.current = false; close() }
  }, [user?.id])
  useEffect(() => {
    alive.current = true
    api('/api/config').then(result => { if (alive.current) setConfig(result.screenshot_import || { enabled: false }) })
      .catch(e => { if (alive.current) setError(uiError(e)) })
      .finally(() => { if (alive.current) setLoading(false) })
    return () => { alive.current = false }
  }, [])
  const cancel = () => { alive.current = false; close() }
  const maxImages = Math.min(SCREENSHOT_COUNT_MAX, config?.max_images || SCREENSHOT_COUNT_MAX)
  const pickImages = async ev => {
    const files = [...(ev.target.files || [])]; ev.target.value = ''
    if (!files.length || busyLock.current) return
    setConsent(false)
    if (files.length > maxImages) { setError(t('Select up to {0} screenshots at a time', maxImages)); return }
    busyLock.current = true; setBusy(true); setError('')
    try {
      const prepared = []
      for (const file of files) prepared.push(await prepareScreenshot(file, { maxBytes: config?.max_image_bytes }))
      if (alive.current) { setImages(prepared); setReview(null); setAllowHistory(false) }
    } catch (e) { if (alive.current) setError(uiError(e)) }
    finally { busyLock.current = false; if (alive.current) setBusy(false) }
  }
  const recognize = async () => {
    if (busyLock.current || !images.length || !consent || !config?.enabled || useStore.getState().user?.id !== owner.current) return
    busyLock.current = true; setBusy(true); setError('')
    try {
      const response = await api('/api/plan-import/screenshots', { method: 'POST', timeout: 60000, body: JSON.stringify({ images: images.map(({ dataUrl }) => ({ dataUrl })), consent: true }) })
      if (alive.current) {
        const draft = createScreenshotReview(response.draft, customEx)
        draft.routines.forEach(r => r.exercises.forEach(e => { e._reviewKey = ++nextKey.current }))
        setReview(draft); setAllowHistory(false)
      }
    } catch (e) { if (alive.current) setError(uiError(e)) }
    finally { busyLock.current = false; if (alive.current) setBusy(false) }
  }
  const setExercise = (ri, ei, exercise) => setReview(prev => ({ ...prev, routines: prev.routines.map((routine, index) => index === ri ? { ...routine, exercises: routine.exercises.map((old, at) => at === ei ? exercise : old) } : routine) }))
  const removeExercise = (ri, ei) => setReview(prev => ({ ...prev, routines: prev.routines.map((routine, index) => index === ri ? { ...routine, exercises: routine.exercises.filter((_, at) => at !== ei) } : routine) }))
  const needsConversion = review && review.kind !== 'plan'
  let validated = null, invalid = ''
  if (review) {
    try { validated = buildScreenshotPlanBundle(review, { unit: useStore.getState().S.unit || 'kg', allowHistory }) }
    catch (e) { invalid = uiError(e) }
  }
  const apply = () => {
    if (applied.current || busyLock.current || !alive.current || useStore.getState().user?.id !== owner.current) return
    try {
      const bundle = buildScreenshotPlanBundle(review, { unit: useStore.getState().S.unit || 'kg', allowHistory })
      applied.current = true
      useStore.getState().update(s => mergePlan(s, bundle, { schedule: false }))
      close()
      useUI.getState().toast(t('Screenshot plan added'))
    } catch (e) { applied.current = false; setError(uiError(e)) }
  }
  return <div className="screenshot-import">
    <h3>{t('Import a plan from screenshots')}</h3>
    <div className="small dim" style={{ lineHeight: 1.5, marginBottom: 14 }}>{t('Review the recognized exercises and numbers before adding new routines. Your existing plan and weekly schedule stay as they are.')}</div>
    {loading ? <p role="status">{t('Loading…')}</p> : !config ? <p>{t('Screenshot recognition settings could not be loaded. Please try again later.')}</p> : !config.enabled ? <p>{t('Screenshot recognition is not configured yet. The administrator needs to connect DeepSeek before anyone can use it.')}</p> : !user ? <p>{t('Sign in before importing screenshots')}</p> : !review ? <>
      <Button variant="tinted" icon="image" disabled={busy} onClick={() => input.current?.click()}>{images.length ? t('Choose different screenshots') : t('Choose screenshots')}</Button>
      <input ref={input} type="file" accept="image/png,image/jpeg,image/webp" multiple hidden onChange={pickImages} />
      <div className="small dim" style={{ marginTop: 7 }}>{t('Up to {0} screenshots. PNG, JPEG or WebP; original files up to 12 MB each.', maxImages)}</div>
      {config.daily_user_limit > 0 && <div className="small dim" style={{ marginTop: 5 }}>{t('Each account can recognize screenshots up to {0} times per day.', config.daily_user_limit)}</div>}
      {!!images.length && <div className="screenshot-thumbnails">{images.map((image, i) => <figure key={i}><img src={image.dataUrl} alt={t('Selected screenshot {0}', i + 1)} /><figcaption>{i + 1}</figcaption></figure>)}</div>}
      <p className="small dim">{t('The selected screenshots will be sent to DeepSeek for recognition. This app does not permanently store the original images.')}</p>
      <label className="screenshot-check"><input type="checkbox" checked={consent} disabled={busy || !images.length} onChange={e => setConsent(e.target.checked)} /><span>{t('I agree to send these screenshots to DeepSeek for recognition')}</span></label>
      <Button variant="primary" icon="sparkles" disabled={busy || !images.length || !consent} onClick={recognize}>{busy ? t('Processing screenshots…') : t('Recognize screenshots')}</Button>
    </> : <>
      <h4 className="sec">{t('Review your new plan')}</h4>
      <DraftTextField aria-label={t('Plan name')} placeholder={t('Plan name')} value={review.name || ''} onChange={e => setReview(prev => ({ ...prev, name: e.target.value }))} />
      {(review.warnings || []).map((warning, i) => <p className="small screenshot-warning" key={i}>{warning}</p>)}
      {needsConversion && <label className="screenshot-check"><input type="checkbox" checked={allowHistory} onChange={e => setAllowHistory(e.target.checked)} /><span>{t('Convert these training records or unclear screenshots into a new training plan')}</span></label>}
      {review.routines.map((routine, ri) => <section className="screenshot-routine" key={ri}>
        <label className="screenshot-field"><span>{t('Routine name')}</span><DraftTextField aria-label={t('Routine name')} value={routine.name || ''} onChange={e => setReview(prev => ({ ...prev, routines: prev.routines.map((old, index) => index === ri ? { ...old, name: e.target.value } : old) }))} /></label>
        {routine.day != null && <div className="small dim">{t('Recognized day: {0}', t(['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][routine.day]))}</div>}
        {routine.exercises.map((exercise, ei) => <ExerciseDraft key={exercise._reviewKey} exercise={exercise} customEx={customEx} onChange={next => setExercise(ri, ei, next)} onRemove={() => removeExercise(ri, ei)} />)}
      </section>)}
      {invalid && <p className="small screenshot-warning" role="status">{invalid}</p>}
      <div className="small dim" style={{ marginBottom: 12 }}>{t('Only new routines are added. No workout history is imported, and your weekly schedule is not replaced.')}</div>
      <Button variant="primary" disabled={!validated || busy} onClick={apply}>{t('Confirm and add to my plan')}</Button>
      <Button variant="ghost" disabled={busy} onClick={() => { setReview(null); setError('') }}>{t('Choose screenshots again')}</Button>
    </>}
    {error && <p role="alert" className="small screenshot-warning">{error}</p>}
    <Button variant="ghost" onClick={cancel}>{t('Cancel')}</Button>
  </div>
}
