// @vitest-environment happy-dom
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import ScreenshotPlanImport from './ScreenshotPlanImport.jsx'
import { api } from '../lib/api.js'
import { prepareScreenshot } from '../lib/screenshot-image.js'

const mocks = vi.hoisted(() => ({ S: null, user: { id: 'test-user' }, update: vi.fn(), toast: vi.fn() }))
vi.mock('../store/useStore.js', () => {
  const snapshot = () => ({ S: mocks.S, user: mocks.user, update: mocks.update })
  const useStore = selector => selector(snapshot())
  useStore.getState = snapshot
  return { useStore }
})
vi.mock('../store/useUI.js', () => ({ useUI: { getState: () => ({ toast: mocks.toast }) } }))
vi.mock('../lib/api.js', () => ({ api: vi.fn() }))
vi.mock('../lib/screenshot-image.js', () => ({ SCREENSHOT_COUNT_MAX: 3, prepareScreenshot: vi.fn() }))

const enabled = { screenshot_import: { enabled: true, provider: 'DeepSeek', max_images: 3, max_image_bytes: 1048576, daily_user_limit: 5 } }
const draft = overrides => ({ version: 1, kind: 'plan', name: '导入计划', warnings: [], routines: [{ name: '胸部训练', day: 1, exercises: [{ name: '杠铃卧推', sets: 3, reps: 8, mode: 'reps', weight: 40, unit: 'kg', restSeconds: 90, source: '杠铃卧推 3组×8次', warnings: [] }] }], ...overrides })
let root, host, close
const settle = () => act(async () => { await Promise.resolve(); await Promise.resolve() })
const button = label => [...host.querySelectorAll('button')].find(b => b.textContent.trim() === label)
const field = label => host.querySelector(`[aria-label="${label}"]`)
const postCalls = () => api.mock.calls.filter(([path]) => path === '/api/plan-import/screenshots')
const type = (el, value) => {
  Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value').set.call(el, value)
  el.dispatchEvent(new Event('input', { bubbles: true }))
}
async function mount() {
  act(() => root.render(<ScreenshotPlanImport close={close} />))
  await settle()
}
async function choose(count = 1) {
  const input = host.querySelector('input[type="file"]')
  Object.defineProperty(input, 'files', { value: Array.from({ length: count }, (_, i) => ({ name: `screenshot-${i}.png` })), configurable: true })
  await act(async () => { input.dispatchEvent(new Event('change', { bubbles: true })); await Promise.resolve() })
  await settle()
}
async function recognize() {
  await choose()
  act(() => host.querySelector('input[type="checkbox"]').click())
  await act(async () => { button('Recognize screenshots').click(); await Promise.resolve() })
  await settle()
}

beforeEach(() => {
  globalThis.IS_REACT_ACT_ENVIRONMENT = true
  vi.clearAllMocks()
  mocks.S = { unit: 'kg', customEx: [], routines: [{ id: 'original', name: '原计划', ex: [] }], week: { 2: ['original'] }, workouts: [{ date: '2026-10-01', entries: [] }], exWeights: { '0025': 50 } }
  mocks.user = { id: 'test-user' }
  mocks.update.mockImplementation(mut => mut(mocks.S))
  api.mockImplementation(async path => path === '/api/config' ? enabled : { draft: draft() })
  prepareScreenshot.mockResolvedValue({ name: 'screenshot.png', dataUrl: 'data:image/jpeg;base64,c2NyZWVuc2hvdA==', bytes: 10 })
  host = document.createElement('div'); document.body.appendChild(host)
  root = createRoot(host); close = vi.fn()
})
afterEach(() => { act(() => root.unmount()); host.remove() })

describe('Screenshot plan import', () => {
  it('explains an unconfigured service and performs no writes or recognition calls', async () => {
    api.mockResolvedValue({ screenshot_import: { enabled: false } })
    await mount()
    expect(host.textContent).toContain('Screenshot recognition is not configured yet')
    expect(host.querySelector('input[type="file"]')).toBeNull()
    expect(mocks.update).not.toHaveBeenCalled()
    expect(postCalls()).toHaveLength(0)
  })

  it('does not send selected screenshots until the user explicitly consents', async () => {
    await mount(); await choose()
    expect(button('Recognize screenshots').disabled).toBe(true)
    act(() => button('Recognize screenshots').click())
    expect(postCalls()).toHaveLength(0)
    expect(mocks.update).not.toHaveBeenCalled()
    act(() => host.querySelector('input[type="checkbox"]').click())
    expect(button('Recognize screenshots').disabled).toBe(false)
  })

  it('hides the daily quota for unlimited recognition and still requires consent', async () => {
    api.mockImplementation(async path => path === '/api/config'
      ? { screenshot_import: { ...enabled.screenshot_import, daily_user_limit: 0, daily_site_limit: 0 } }
      : { draft: draft() })
    await mount(); await choose()
    expect(host.textContent).not.toContain('times per day')
    expect(button('Recognize screenshots').disabled).toBe(true)
    expect(postCalls()).toHaveLength(0)
    act(() => host.querySelector('input[type="checkbox"]').click())
    expect(button('Recognize screenshots').disabled).toBe(false)
  })

  it('rejects selecting more than three screenshots before processing', async () => {
    await mount(); await choose(4)
    expect(host.querySelector('[role="alert"]').textContent).toContain('Select up to 3')
    expect(prepareScreenshot).not.toHaveBeenCalled()
    expect(postCalls()).toHaveLength(0)
  })

  it('keeps all profile data untouched when recognition fails', async () => {
    const before = structuredClone(mocks.S)
    api.mockImplementation(async path => { if (path === '/api/config') return enabled; throw new Error('识别服务暂时不可用') })
    await mount(); await recognize()
    expect(host.querySelector('[role="alert"]').textContent).toContain('识别服务暂时不可用')
    expect(mocks.S).toEqual(before)
    expect(mocks.update).not.toHaveBeenCalled()
  })

  it('ignores an in-flight recognition result after cancellation', async () => {
    let resolve
    api.mockImplementation(path => path === '/api/config' ? Promise.resolve(enabled) : new Promise(r => { resolve = r }))
    await mount(); await choose()
    act(() => host.querySelector('input[type="checkbox"]').click())
    act(() => button('Recognize screenshots').click())
    act(() => button('Cancel').click())
    await act(async () => resolve({ draft: draft() }))
    expect(close).toHaveBeenCalledOnce()
    expect(button('Confirm and add to my plan')).toBeUndefined()
    expect(mocks.update).not.toHaveBeenCalled()
  })

  it('never applies one account’s draft after the current account changes', async () => {
    await mount(); await recognize()
    const confirm = button('Confirm and add to my plan')
    mocks.user = { id: 'different-user' }
    act(() => confirm.click())
    expect(mocks.update).not.toHaveBeenCalled()
    act(() => root.render(<ScreenshotPlanImport close={close} />))
    expect(close).toHaveBeenCalledOnce()
  })

  it('allows edits, then appends only once while preserving history, schedule and saved weights', async () => {
    const before = structuredClone(mocks.S)
    await mount(); await recognize()
    expect(mocks.update).not.toHaveBeenCalled()
    act(() => type(field('Working sets'), '4'))
    act(() => type(field('Target repetitions'), '12'))
    act(() => type(field('Target weight (optional)'), '45'))
    const confirm = button('Confirm and add to my plan')
    expect(confirm.disabled).toBe(false)
    act(() => { confirm.click(); confirm.click() })
    expect(mocks.update).toHaveBeenCalledOnce()
    expect(mocks.S.routines).toHaveLength(2)
    expect(mocks.S.routines[1].ex[0]).toMatchObject({ id: '0025', sets: 4, reps: 12, weight: 45, restSec: 90 })
    expect(mocks.S.routines[0]).toEqual(before.routines[0])
    expect(mocks.S.week).toEqual(before.week)
    expect(mocks.S.workouts).toEqual(before.workouts)
    expect(mocks.S.exWeights).toEqual(before.exWeights)
    expect(postCalls()[0][1]).toMatchObject({ method: 'POST', timeout: 60000 })
    expect(JSON.parse(postCalls()[0][1].body)).toEqual({ images: [{ dataUrl: 'data:image/jpeg;base64,c2NyZWVuc2hvdA==' }], consent: true })
  })

  it('requires explicit conversion of history and manual resolution of missing numbers or units', async () => {
    const result = draft({ kind: 'history' })
    result.routines[0].exercises[0].sets = null
    result.routines[0].exercises[0].unit = null
    api.mockImplementation(async path => path === '/api/config' ? enabled : { draft: result })
    await mount(); await recognize()
    expect(button('Confirm and add to my plan').disabled).toBe(true)
    act(() => host.querySelector('input[type="checkbox"]').click())
    act(() => type(field('Working sets'), '3'))
    expect(button('Confirm and add to my plan').disabled).toBe(true)
    act(() => { field('Weight unit').value = 'kg'; field('Weight unit').dispatchEvent(new Event('change', { bubbles: true })) })
    expect(button('Confirm and add to my plan').disabled).toBe(false)
    act(() => button('Cancel').click())
    expect(mocks.update).not.toHaveBeenCalled()
  })

  it('lets an unresolved action become an explicit custom draft without writing before confirmation', async () => {
    const result = draft()
    result.routines[0].exercises[0].name = '我的特殊卧推'
    api.mockImplementation(async path => path === '/api/config' ? enabled : { draft: result })
    await mount(); await recognize()
    expect(button('Confirm and add to my plan').disabled).toBe(true)
    act(() => host.querySelector('input[type="checkbox"]').click())
    act(() => { field('Choose a body part').value = 'chest'; field('Choose a body part').dispatchEvent(new Event('change', { bubbles: true })) })
    expect(mocks.update).not.toHaveBeenCalled()
    expect(mocks.S.customEx).toEqual([])
    expect(button('Confirm and add to my plan').disabled).toBe(false)
    act(() => button('Confirm and add to my plan').click())
    expect(mocks.S.customEx).toHaveLength(1)
    expect(mocks.S.customEx[0]).toMatchObject({ n: '我的特殊卧推', bp: 'chest', custom: true })
  })
})
