// @vitest-environment happy-dom
import React, { act } from 'react'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createRoot } from 'react-dom/client'
import { useStore } from './store/useStore.js'
import { useUI } from './store/useUI.js'
import { logPastWorkoutSheet } from './sheets.jsx'
import { todayISO } from './lib/format.js'

const mounted = []
function type(el, value) {
  Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value').set.call(el, value)
  el.dispatchEvent(new Event('input', { bubbles: true }))
}
function mountTopSheet() {
  const sheet = useUI.getState().sheets.at(-1)
  const host = document.createElement('div')
  document.body.appendChild(host)
  const root = createRoot(host)
  mounted.push(root)
  act(() => root.render(sheet.render(() => useUI.getState().closeSheet(sheet.id))))
  return host
}
const button = (host, text) => [...host.querySelectorAll('button')].find(b => b.textContent.trim() === text)
const cssSource = readFileSync(resolve(process.cwd(), 'src/index.css'), 'utf8')

describe('log a past workout', () => {
  beforeEach(() => {
    globalThis.IS_REACT_ACT_ENVIRONMENT = true
    useUI.setState({ sheets: [], toasts: [] })
    useStore.setState(s => ({ S: { ...s.S, active: null, routines: [], workouts: [{ id: 'old', d: todayISO(), start: 1, end: 2, name: 'Old', entries: [], prs: [] }] } }))
    document.body.innerHTML = ''
  })
  afterEach(() => { act(() => { mounted.splice(0).forEach(root => root.unmount()) }) })

  it('refuses while a workout is running', () => {
    const toast = vi.fn()
    useUI.setState({ toast })
    useStore.setState(s => ({ S: { ...s.S, active: { id: 'a', entries: [] } } }))
    logPastWorkoutSheet()
    expect(useUI.getState().sheets).toHaveLength(0)
    expect(toast).toHaveBeenCalledWith('Finish the current workout first.')
  })

  it('asks what to do when the day already has a workout', () => {
    logPastWorkoutSheet()
    const host = mountTopSheet()
    expect(host.querySelector('h3').textContent).toBe('Log a past workout')
    act(() => { type(host.querySelector('input[type=date]'), todayISO()) })
    act(() => { button(host, 'Continue').click() })
    const prompt = mountTopSheet()
    expect(prompt.textContent).toContain('There is already a workout on that day.')
    expect(['Replace', 'Add as second workout', 'Cancel'].map(t => !!button(prompt, t))).toEqual([true, true, true])
    expect(useStore.getState().S.active).toBeNull()
  })

  it('a workout with photos or videos says Replace moves them to the new one', () => {
    const ref = n => ({ kind: 'image', hash: String(n).repeat(64), mime: 'image/webp', size: 10, width: 8, height: 6, at: 1 })
    logPastWorkoutSheet()
    let host = mountTopSheet()
    act(() => { type(host.querySelector('input[type=date]'), todayISO()) })
    act(() => { button(host, 'Continue').click() })
    expect(mountTopSheet().textContent).not.toContain('new workout.')
    useStore.setState(s => ({ S: { ...s.S, workouts: [{ ...s.S.workouts[0], media: [ref(1), ref(2)] }] } }))
    logPastWorkoutSheet()
    host = mountTopSheet()
    act(() => { type(host.querySelector('input[type=date]'), todayISO()) })
    act(() => { button(host, 'Continue').click() })
    expect(mountTopSheet().textContent).toContain('Its 2 photos or videos move to the new workout.')
  })

  // The Date and Start-time rows are the only .lrow rows in the app that pair a title with a
  // fixed-width field and nothing that can give way. A pixel floor under the title column therefore
  // comes straight out of the field: 104px pushed the date input 23px off a 320px screen, calendar
  // picker and all, so there was no way to open the picker on a small phone. The floor has to be the
  // row's own longest word (min-width:auto), which these short titles barely ask for.
  it('gives the date and time fields a title column that can shrink', () => {
    logPastWorkoutSheet()
    const host = mountTopSheet()
    const fields = [...host.querySelectorAll('.lrow input.timef')]
    expect(fields.map(i => i.type)).toEqual(['date', 'time'])
    for (const field of fields) expect(field.closest('.lrow').querySelectorAll('.lrow-v')).toHaveLength(0)
    const rule = cssSource.match(/^\.lrow-m\{([^}]*)\}/m)
    expect(rule?.[1]).toContain('min-width:auto')
    expect(rule[1]).not.toMatch(/min-width:\s*[\d.]/)
    // and where even the longest word leaves no room for the field (Polish "Godzina rozpoczęcia"
    // at 320px), the field drops onto its own line rather than over the edge of the card.
    expect(cssSource).toContain('.lrow:has(.timef){flex-wrap:wrap}')
    expect(cssSource).toContain('.lrow>.timef{margin-inline-start:auto}')
  })

  it('starts a backfilled session straight away on a free day', () => {
    logPastWorkoutSheet()
    const host = mountTopSheet()
    act(() => { type(host.querySelector('input[type=date]'), '2020-01-02') })
    act(() => { button(host, 'Continue').click() })
    const A = useStore.getState().S.active
    expect(A.d).toBe('2020-01-02')
    expect(new Date(A.start).getHours()).toBe(18)
    expect(A.backfill).toEqual({ durationMin: 60, replaceId: null })
  })

  // The same keystroke clamp as the saved workout's duration: a 60 emptied to type 45 read 145.
  it('lets the duration be emptied and retyped, and never starts a session of no length', () => {
    logPastWorkoutSheet()
    const host = mountTopSheet()
    act(() => { type(host.querySelector('input[type=date]'), '2020-01-02') })
    const field = host.querySelector('input.num')
    act(() => { type(field, '') })
    expect(field.value).toBe('')
    act(() => { type(field, '45') })
    act(() => { button(host, 'Continue').click() })
    expect(useStore.getState().S.active.backfill.durationMin).toBe(45)
  })

  // An emptied duration is neither the default hour nor a silent minute (QA 1.3.9): nothing
  // starts until a length is typed, and the sheet says so.
  it('an emptied duration starts nothing and asks for a length', () => {
    logPastWorkoutSheet()
    const host = mountTopSheet()
    act(() => { type(host.querySelector('input[type=date]'), '2020-01-02') })
    act(() => { type(host.querySelector('input.num'), '') })
    expect(host.textContent).toContain('Enter how long it took — at least 1 minute.')
    act(() => { button(host, 'Continue').click() })
    expect(useStore.getState().S.active).toBeFalsy()
    act(() => { type(host.querySelector('input.num'), '1') })
    act(() => { button(host, 'Continue').click() })
    expect(useStore.getState().S.active.backfill.durationMin).toBe(1)
  })
})
