// @vitest-environment happy-dom
// The admin drill-down (QA C16): a profile whose stored workouts hold a null or otherwise
// shapeless entry must still open, because the sheet host sits outside the route's
// ErrorBoundary — a throw here blanked the whole app and left the account un-disableable.
import React, { act } from 'react'
import { createRoot } from 'react-dom/client'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import Admin from './Admin.jsx'
import { _setLangState } from '../lib/i18n-core.js'
import zh from '../locales/zh.js'

globalThis.IS_REACT_ACT_ENVIRONMENT = true

const mocks = vi.hoisted(() => ({ answers: {}, sheets: [] }))
vi.mock('../lib/api.js', () => ({
  api: path => {
    const key = path.split('?')[0]
    return key in mocks.answers ? Promise.resolve(mocks.answers[key]) : Promise.reject(new Error('not found'))
  }
}))
vi.mock('../store/useStore.js', () => {
  const snap = () => ({ user: { id: 'adm', name: 'Admin', admin: true }, S: {} })
  const useStore = selector => selector ? selector(snap()) : snap()
  useStore.getState = snap
  return { useStore }
})
vi.mock('../store/useUI.js', () => {
  const snap = () => ({ toast: () => {}, openSheet: render => mocks.sheets.push(render) })
  const useUI = selector => selector ? selector(snap()) : snap()
  useUI.getState = snap
  return { useUI }
})
vi.mock('react-router-dom', () => ({ useNavigate: () => () => {} }))
vi.mock('../sheets.jsx', () => ({ confirmSheet: vi.fn() }))
vi.mock('./AdminCoach.jsx', () => ({ default: () => null }))

const mounted = []
function render(el) {
  const host = document.createElement('div')
  document.body.appendChild(host)
  const root = createRoot(host)
  mounted.push(root)
  act(() => root.render(el))
  return host
}
const settle = () => act(() => new Promise(r => setTimeout(r, 0)))

const good = { id: 'w1', name: 'Push day', d: '2026-09-10', start: 1000, end: 61000, entries: [{ sets: [{ done: true }, { done: false }] }] }

beforeEach(() => {
  document.body.innerHTML = ''
  mocks.sheets.length = 0
  mocks.answers = {
    '/api/admin/users': { users: [{ id: 'u1', name: 'Mallory', workouts: 2, lastSync: null, disabled: false }], invite_only: false },
    '/api/admin/invites': { invites: [] },
    '/api/admin/audit': { rows: [] },
    '/api/admin/user': {
      user: { id: 'u1', name: 'Mallory', created: '2026-09-01T00:00:00Z', disabled: false, admin: false },
      unit: 'kg', lastSync: null, routines: [], bodyweight: [],
      // What GET /api/admin/user hands over for a document written before PUT /api/data dropped
      // such entries: a null, and a bare object without entries, next to a real session.
      workouts: [null, good, {}]
    }
  }
})
afterEach(() => { act(() => { mounted.splice(0).forEach(root => root.unmount()) }); _setLangState('en', {}, null, null) })

describe('Admin user drill-down', () => {
  it('opens a profile with malformed workout entries and still offers "Disable account"', async () => {
    const page = render(<Admin />)
    await settle()
    const row = [...page.querySelectorAll('.item')].find(el => el.textContent.includes('Mallory'))
    expect(row).toBeTruthy()
    act(() => row.click())
    expect(mocks.sheets.length).toBe(1)
    const sheet = render(mocks.sheets[0](() => {}))
    await settle()
    const buttons = [...sheet.querySelectorAll('button')].map(b => b.textContent)
    expect(buttons).toContain('Disable account')
    // The one real session is listed; the two shapeless entries are skipped, not drawn as blanks.
    const rows = [...sheet.querySelectorAll('.list > div')]
    expect(rows.length).toBe(1)
    expect(rows[0].textContent).toContain('Push day')
    expect(rows[0].textContent).toContain('1 sets')
  })
})

// The users call failing, or answering without a list, used to leave "Loading…" up for good —
// what a paired phone that had lost its pairing showed its admin, and all it showed.
describe('Admin when the users cannot be loaded', () => {
  const text = page => page.textContent
  it('an answer without a list is an error, not an endless "Loading…"', async () => {
    mocks.answers['/api/admin/users'] = {}
    const page = render(<Admin />)
    await settle()
    expect(text(page)).not.toContain('Loading…')
    expect(text(page)).toContain('Could not load the users')
    expect(text(page)).toContain('The server answered without a list of users.')
  })

  it('a failed call says why, and "Try again" loads the list once the server answers', async () => {
    delete mocks.answers['/api/admin/users']
    const page = render(<Admin />)
    await settle()
    expect(page.querySelector('[role="alert"]').textContent).toContain('not found')

    mocks.answers['/api/admin/users'] = { users: [{ id: 'u1', name: 'Mallory', workouts: 2, lastSync: null, disabled: false }], invite_only: false }
    const retry = [...page.querySelectorAll('button')].find(b => b.textContent === 'Try again')
    act(() => retry.click())
    await settle()
    expect(page.querySelector('[role="alert"]')).toBeNull()
    expect(text(page)).toContain('1 users')
    expect([...page.querySelectorAll('.item')].some(el => el.textContent.includes('Mallory'))).toBe(true)
  })

  it('a list that loaded stays up when a later update fails, marked as the last one', async () => {
    const page = render(<Admin />)
    await settle()
    delete mocks.answers['/api/admin/users']
    const refresh = page.querySelector('[aria-label="refresh"]')
    act(() => refresh.click())
    await settle()
    expect(text(page)).toContain('The last update failed')
    expect([...page.querySelectorAll('.item')].some(el => el.textContent.includes('Mallory'))).toBe(true)
  })
})


describe('Chinese operator UI', () => {
  it('renders the dashboard and user actions in Chinese while preserving account and workout names', async () => {
    _setLangState('zh', zh, null, null, false)
    const page = render(<Admin />)
    await settle()
    expect(page.textContent).toContain('管理后台')
    expect(page.textContent).toContain('邀请码')
    expect(page.textContent).not.toMatch(/Training now|Invite codes|No codes yet|Admin/)
    const row = [...page.querySelectorAll('.item')].find(el => el.textContent.includes('Mallory'))
    act(() => row.click())
    const sheet = render(mocks.sheets[0](() => {}))
    await settle()
    expect(sheet.textContent).toContain('Mallory')
    expect(sheet.textContent).toContain('Push day')
    expect(sheet.textContent).toContain('停用账号')
    expect(sheet.textContent).toContain('下载用户数据')
    expect(sheet.textContent).not.toMatch(/Disable account|Download their data|Last sync|joined/)
  })
})
