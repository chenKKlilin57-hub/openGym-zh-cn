// @vitest-environment happy-dom
import React, { act } from 'react'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { createRoot } from 'react-dom/client'
import { useStore } from './store/useStore.js'
import { useUI } from './store/useUI.js'
import { todayISO } from './lib/format.js'
import { calendarSheet } from './sheets.jsx'

const mounted = []

function renderTop() {
  const sheet = useUI.getState().sheets.at(-1)
  const host = document.createElement('div')
  document.body.appendChild(host)
  const root = createRoot(host)
  mounted.push(root)
  act(() => root.render(sheet.render(() => useUI.getState().closeSheet(sheet.id))))
  return host
}

describe('Calendar canonical workout days', () => {
  let original

  beforeEach(() => {
    globalThis.IS_REACT_ACT_ENVIRONMENT = true
    original = useStore.getState().S
    useUI.setState({ sheets: [] })
    document.body.innerHTML = ''
  })

  afterEach(() => {
    act(() => { mounted.splice(0).forEach(root => root.unmount()) })
    useStore.setState({ S: original })
  })

  it('keeps multiple legacy sessions on the heatmap fallback day clickable in Calendar', () => {
    const day = todayISO()
    const start = new Date(day + 'T09:00:00').getTime()
    useStore.setState({ S: {
      ...original,
      workouts: [
        { id: 'legacy-a', d: '', start, end: start + 15 * 60000, name: 'Legacy A', vol: 100, entries: [] },
        { id: 'legacy-b', d: 'not-a-day', start: start + 30 * 60000, end: start + 45 * 60000, name: 'Legacy B', vol: 200, entries: [] },
      ],
    } })

    calendarSheet(day)
    const host = renderTop()
    expect(host.textContent).toContain('2 workouts')
    const trainedDay = host.querySelector('button.cal-d.has')
    expect(trainedDay).toBeTruthy()

    act(() => trainedDay.click())
    const sessions = renderTop()
    expect(sessions.textContent).toContain('Legacy A')
    expect(sessions.textContent).toContain('Legacy B')
  })

  it('shows workout types directly on dates and retains the detail action', () => {
    useStore.setState({ S: { ...original, workouts: [{
      id: 'chest', d: '2026-10-05', name: 'Chest session', start: 1, end: 60001,
      entries: [{ id: '0025', sets: [{ done: true, w: 50, r: 10 }] }],
    }] } })
    calendarSheet('2026-10-05')
    const host = renderTop()
    const day = host.querySelector('.cal-d.has')
    expect(day.querySelector('.cal-tags').textContent).toBe('Chest')
    expect(day.getAttribute('aria-label')).toContain('Chest session')
    act(() => day.click())
    expect(renderTop().textContent).toContain('Chest session')
  })

  it('keeps dense days compact and exposes all types in the accessible label', () => {
    useStore.setState({ S: { ...original, workouts: [{
      d: '2026-10-05', entries: ['chest', 'deltoids', 'abs'].map(muscle => ({
        id: muscle, muscleSnapshot: { primaries: [muscle] }, sets: [{ done: true }],
      })),
    }] } })
    calendarSheet('2026-10-05')
    const day = renderTop().querySelector('.cal-d.has')
    expect(day.querySelector('.cal-tags').textContent).toBe('Chest·Shoulders+1')
    expect(day.getAttribute('aria-label')).toContain('Core')
  })

  it('switches months without losing or misplacing workout tags', () => {
    useStore.setState({ S: { ...original, workouts: [{ d: '2026-10-05', name: 'Chest', entries: [] }] } })
    calendarSheet('2026-10-05')
    const host = renderTop()
    act(() => host.querySelector('[aria-label="Previous month"]').click())
    expect(host.querySelector('.cal-d.has')).toBeNull()
    act(() => host.querySelector('[aria-label="Next month"]').click())
    expect(host.querySelector('.cal-d.has .cal-tags').textContent).toBe('Chest')
  })
})
