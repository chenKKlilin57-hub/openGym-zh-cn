// Completeness gate for the Chinese private build, including runtime-generated labels.
import assert from 'node:assert/strict'
import { readdirSync, readFileSync, statSync } from 'node:fs'
import { EXDB } from '../frontend/src/lib/exercises-data.js'
import ui from '../frontend/src/locales/zh.js'
import names from '../frontend/src/exercise-names/zh.js'
import steps from '../frontend/src/instr/zh.js'
import { TEMPLATES } from '../frontend/src/lib/structuralBalanceTemplates.js'
import { _setLangState, exerciseNameFor, instrFor } from '../frontend/src/lib/i18n-core.js'

const root = new URL('../frontend/src/', import.meta.url)
const files = []
function walk(dir) {
  for (const f of readdirSync(dir)) {
    const file = new URL(f, dir)
    if (statSync(file).isDirectory()) {
      if (!['locales', 'instr', 'exercise-names', 'node_modules'].includes(f)) walk(new URL(f + '/', dir))
    } else if (/\.(jsx?|mjs)$/.test(f) && !/\.test\./.test(f)) files.push(file)
  }
}
walk(root)
const keys = new Set()
const literal = /(^|[^A-Za-z0-9_$.])t\(\s*(['"])((?:\\.|(?!\2)[^\\])*)\2/g
for (const file of files) for (const m of readFileSync(file, 'utf8').matchAll(literal)) keys.add(m[3].replace(/\\(['"\\])/g, '$1'))
for (const e of EXDB) for (const field of ['bp', 'eq', 'tg', 'mg', 'sm']) {
  for (const label of (Array.isArray(e[field]) ? e[field] : e[field] ? [e[field]] : [])) keys.add(label)
}
for (const template of Object.values(TEMPLATES)) {
  keys.add(template.label)
  for (const role of template.roles) keys.add(role.label)
}
for (const key of keys) assert.ok(ui[key]?.trim(), 'Missing Chinese UI: ' + key)
const marks = s => [...s.matchAll(/\{\d+\}/g)].map(m => m[0]).sort().join(' ')
for (const [key, value] of Object.entries(ui)) assert.equal(marks(key), marks(value), 'Changed parameter: ' + key)
assert.deepEqual(Object.keys(names).sort(), EXDB.map(e => e.id).sort(), 'Chinese catalogue IDs must exactly match')
assert.deepEqual(Object.keys(steps).sort(), EXDB.map(e => e.id).sort(), 'Chinese instruction IDs must exactly match')
_setLangState('zh', ui, steps, names, false)
for (const e of EXDB) {
  assert.ok(/\p{Script=Han}/u.test(exerciseNameFor(e)), 'Empty/untranslated name: ' + e.id)
  assert.ok(!/[A-Za-z]/.test(exerciseNameFor(e)), 'English name remains: ' + e.id)
  assert.equal(instrFor(e).length, e.st.length, 'Missing instruction: ' + e.id)
  for (const s of instrFor(e)) assert.ok(s.trim() && /\p{Script=Han}/u.test(s) && !/[A-Za-z]/.test(s), 'Untranslated instruction: ' + e.id)
}
console.log(`PASS: ${Object.keys(ui).length} Chinese UI keys, ${keys.size} source/dynamic labels, ${EXDB.length} names, ${Object.values(steps).flat().length} steps; IDs and parameters intact.`)
