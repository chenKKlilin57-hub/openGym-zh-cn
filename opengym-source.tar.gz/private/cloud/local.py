"""Run the isolated Supabase-backed build locally on macOS."""
import argparse, os, pathlib, plistlib, shutil, subprocess, sys, time, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[2]
DOMAIN=f'gui/{os.getuid()}'
p=argparse.ArgumentParser()
p.add_argument('action',choices=['start','stop','status','build'])
p.add_argument('--demo',action='store_true',help='隔离的云端测试账号，端口 8082')
a=p.parse_args()
MODE='demo' if a.demo else 'main'
RUN=ROOT/'.cloud-runtime'/MODE
LABEL='local.opengym.cloud.'+MODE
WEB_PORT=8082 if a.demo else 8080
API_PORT=3003 if a.demo else 3002
MEDIA_PORT=8891 if a.demo else 8890
def call(*cmd): return subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def loaded(name): return call('launchctl','print',f'{DOMAIN}/{LABEL}.{name}').returncode==0
def build(): subprocess.run(['npm','run','build'],cwd=ROOT/'frontend',env={**os.environ,'APP_BUILD':'zh-cn-cloud-preview'},check=True)
if a.action=='build': build()
elif a.action=='stop':
    for name in ['web','api','media']:
        if loaded(name):
            r=call('launchctl','bootout',f'{DOMAIN}/{LABEL}.{name}')
            if r.returncode: raise SystemExit(r.stderr)
    print('云端版本机服务已停止；Supabase 数据保留。')
elif a.action=='status':
    for name in ['api','web','media']: print(name,'已加载' if loaded(name) else '已停止')
    print(f'网站：http://localhost:{WEB_PORT}；数据：Supabase（{MODE}）。')
else:
    config=ROOT/'.env.cloud'
    if not config.exists(): raise SystemExit('缺少 .env.cloud；按照 private/cloud/README.md 配置。')
    env={k:os.environ[k] for k in ['PATH','HOME','LANG','TZ'] if k in os.environ}
    for line in config.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith('#') and '=' in line:
            k,v=line.split('=',1);env[k.strip()]=v.strip().strip('"').strip("'")
    if env.get('DATA_BACKEND')!='supabase': raise SystemExit('此脚本仅启动 Supabase 模式。')
    node=shutil.which('node')
    if not node: raise SystemExit('需要 Node.js 22+。')
    if not (ROOT/'frontend/dist/index.html').exists(): build()
    RUN.mkdir(parents=True,exist_ok=True)
    env.update(DATA_DIR=str(RUN/'data'),PORT=str(API_PORT),API_HOST='127.0.0.1',ORIGIN=f'http://localhost:{WEB_PORT}',RP_ID='localhost',API_ORIGIN=f'http://localhost:{WEB_PORT}',API_TARGET=f'http://127.0.0.1:{API_PORT}',MEDIA_TARGET=f'http://127.0.0.1:{MEDIA_PORT}',COACH_DISABLED='1')
    if a.demo:
        env['SUPABASE_INSTANCE']='demo'
        env['SESSION_COOKIE_SUFFIX']='cloud_demo'
    services={
      'api':([node,'server.js'],ROOT/'api',API_PORT),
      'web':([node,str(ROOT/'frontend/node_modules/vite/bin/vite.js'),'preview','--host','127.0.0.1','--port',str(WEB_PORT),'--strictPort'],ROOT/'frontend',WEB_PORT),
      'media':([sys.executable,'-m','http.server',str(MEDIA_PORT),'--bind','127.0.0.1','--directory',str(ROOT/'media')],ROOT,MEDIA_PORT)}
    import socket
    for name,(_,_,port) in services.items():
        if loaded(name): continue
        with socket.socket() as sock:
            if sock.connect_ex(('127.0.0.1',port))==0: raise SystemExit(f'端口 {port} 已被占用；未停止其他程序。')
    for name,(cmd,cwd,_) in services.items():
        if loaded(name): continue
        record=dict(Label=f'{LABEL}.{name}',ProgramArguments=cmd,WorkingDirectory=str(cwd),EnvironmentVariables=env,RunAtLoad=True,KeepAlive=True,StandardOutPath=str(RUN/f'{name}.log'),StandardErrorPath=str(RUN/f'{name}.err.log'))
        file=RUN/f'{name}.plist';file.write_bytes(plistlib.dumps(record));file.chmod(0o600)
        r=call('launchctl','bootstrap',DOMAIN,str(file))
        if r.returncode: raise SystemExit(r.stderr)
    for _ in range(40):
        try:
            with urllib.request.urlopen(f'http://localhost:{WEB_PORT}/api/health',timeout=3) as response:
                if response.status==200: print(f'已启动 Supabase 云端版：http://localhost:{WEB_PORT}（{MODE}）');break
        except OSError: time.sleep(.5)
    else: raise SystemExit('健康检查失败；查看 .cloud-runtime 下的日志。')
