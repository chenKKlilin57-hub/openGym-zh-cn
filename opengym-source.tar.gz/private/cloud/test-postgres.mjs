// Uses an isolated WASM PostgreSQL test runtime, not the user's Supabase project.
// Install outside this repo: npm install --prefix /tmp/opengym-cloud-sql-tests @electric-sql/pglite
// Run: PGLITE_MODULE=/tmp/opengym-cloud-sql-tests/node_modules/@electric-sql/pglite/dist/index.js node private/cloud/test-postgres.mjs
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';
import http from 'node:http';
import { boundPort } from '../../api/test/helpers.mjs';

if (!process.env.PGLITE_MODULE) throw new Error('Set PGLITE_MODULE to the isolated test runtime path');
const { PGlite } = await import(pathToFileURL(process.env.PGLITE_MODULE).href);
const pg = new PGlite();
await pg.exec('create role anon; create role authenticated; create role service_role bypassrls; grant usage on schema public to service_role,anon,authenticated;');
await pg.exec(readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
const funcs = {
  opengym_initialize: ['p_instance', 'p_secret', 'p_vapid'],
  opengym_save_registry: ['p_instance', 'p_registry', 'p_revision'],
  opengym_write_profile: ['p_instance', 'p_uid', 'p_state', 'p_base_rev'],
  opengym_snapshot: ['p_instance'], opengym_restore: ['p_instance','p_snapshot','p_revision']
};
const casts = { opengym_initialize: ['text', 'text', 'jsonb'], opengym_save_registry: ['text', 'jsonb', 'bigint'], opengym_write_profile: ['text', 'text', 'jsonb', 'bigint'], opengym_snapshot:['text'],opengym_restore:['text','jsonb','bigint'] };
const rpc = async (name, args) => {
  const params = funcs[name].map(k => typeof args[k] === 'object' && args[k] !== null ? JSON.stringify(args[k]) : args[k] ?? null);
  const slots = casts[name].map((c,i) => `$${i+1}::${c}`).join(',');
  return (await pg.query(`select public.${name}(${slots}) as result`, params)).rows[0].result;
};

// Verify privileges on the same real schema before using the server-only role.
for (const role of ['anon', 'authenticated']) {
  await pg.exec('set role ' + role);
  await assert.rejects(pg.query('select * from public.opengym_instances'));
  await assert.rejects(rpc('opengym_initialize', { p_instance: 'attack', p_secret: 'a'.repeat(64), p_vapid: {} }));
  await pg.exec('reset role');
}
await pg.exec('set role service_role');
console.log('PASS: schema compiles; anonymous and browser roles cannot read metadata or execute RPCs.');

let offline = false;
const bridge = http.createServer(async (req,res) => {
  res.setHeader('Content-Type','application/json');
  if (offline) { res.writeHead(503); res.end('{}'); return; }
  try {
    assert.equal(req.headers.apikey, 'sb_secret_local_test');
    const url = new URL(req.url,'http://local');
    let result;
    if (req.method === 'POST' && url.pathname.startsWith('/rest/v1/rpc/')) {
      const chunks=[]; for await (const c of req) chunks.push(c);
      const name=url.pathname.split('/').at(-1);
      if (!funcs[name]) throw new Error('unknown RPC');
      result=await rpc(name, JSON.parse(Buffer.concat(chunks)));
    } else {
      const instance=url.searchParams.get('instance_id')?.slice(3);
      if (url.pathname === '/rest/v1/opengym_instances') result=(await pg.query('select registry,revision from public.opengym_instances where instance_id=$1',[instance])).rows;
      else if (url.pathname === '/rest/v1/opengym_profiles') result=(await pg.query('select state from public.opengym_profiles where instance_id=$1 and user_id=$2',[instance,url.searchParams.get('user_id')?.slice(3)])).rows;
      else throw new Error('unknown table');
    }
    res.end(JSON.stringify(result));
  } catch (e) { res.writeHead(400);res.end(JSON.stringify({error:e.message})); }
});
await new Promise(resolve=>bridge.listen(0,'127.0.0.1',resolve));
const root=dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const local=mkdtempSync(join(tmpdir(),'opengym-cloud-test-'));
let child;
let api;
const start=async()=>{
  let log='';
  child=spawn(process.execPath,['server.js'],{cwd:join(root,'api'),env:{...process.env,NODE_ENV:'test',DATA_BACKEND:'supabase',SUPABASE_URL:`http://127.0.0.1:${bridge.address().port}`,SUPABASE_SECRET_KEY:'sb_secret_local_test',SUPABASE_INSTANCE:'test',DATA_DIR:local,PORT:'0',ORIGIN:'http://localhost:8082',RP_ID:'localhost',PASSWORD_LOGIN:'1',ALLOW_GUEST:'0',INVITE_ONLY:'0',COACH_DISABLED:'1'},stdio:['ignore','pipe','pipe']});
  child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);
  api=`http://127.0.0.1:${await boundPort(child,()=>log)}`;
};
const stop=async()=>{ if(child && child.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;} };
const request=async(path,{method='GET',body,cookie}={})=>{
  const response=await fetch(api+path,{method,headers:{Origin:'http://localhost:8082','Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});
  return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')?.split(';')[0]};
};

try {
  await start();
  const password='Cloud-test-only-2026!123';
  const accounts=await Promise.all(['Cloud A','Cloud B'].map(name=>request('/api/register/password',{method:'POST',body:{name,password}})));
  for(const a of accounts) assert.equal(a.status,200);
  const [a,b]=accounts;
  const put=(account,state,baseRev)=>request('/api/data',{method:'PUT',cookie:account.cookie,body:{state,baseRev}});
  assert.equal((await request('/api/data')).status,401);
  const saved=await Promise.all([put(a,{routines:[{id:'rA',name:'A only'}],workouts:[],active:{id:'private'}},0),put(b,{routines:[{id:'rB',name:'B only'}],workouts:[]},0)]);
  for(const r of saved) assert.equal(r.status,200);
  assert.equal((await request('/api/data',{cookie:a.cookie})).body.state.routines[0].id,'rA');
  assert.equal((await request('/api/data?user_id='+b.body.user.id,{cookie:a.cookie})).body.state.routines[0].id,'rA');
  assert.equal((await request('/api/admin/user?id='+b.body.user.id,{cookie:a.cookie})).status,403);
  const conflict=await put(a,{workouts:[{id:'stale'}],routines:[]},0);
  assert.equal(conflict.status,409);assert.equal(conflict.body.rev,1);
  assert.equal((await request('/api/data',{cookie:a.cookie})).body.state.active,undefined);
  console.log('PASS: real API registration, two-account isolation, spoofed user/admin access, cloud state writes and revision conflicts.');

  offline=true;
  assert.equal((await put(a,{workouts:[{id:'lost'}],routines:[]},1)).status,503);
  offline=false;
  assert.equal((await request('/api/data',{cookie:a.cookie})).body.state.routines[0].id,'rA');
  await stop();await start();
  assert.equal((await request('/api/data',{cookie:a.cookie})).body.state.routines[0].id,'rA');
  const login=await request('/api/login/password',{method:'POST',body:{name:'Cloud B',password}});
  assert.equal(login.status,200);
  assert.equal((await request('/api/data',{cookie:login.cookie})).body.state.routines[0].id,'rB');
  assert.equal(readdirSync(local).some(n=>n==='db.json'||n==='secret'||n.startsWith('state-')),false);
  console.log('PASS: outage returns 503, no failed-write mutation, restart preserves accounts/states/session keys, no local auth/state fallback.');

  const row=(await pg.query("select registry,revision from public.opengym_instances where instance_id='test'")).rows[0];
  const stale=await rpc('opengym_save_registry',{p_instance:'test',p_registry:row.registry,p_revision:row.revision-1});
  assert.equal(stale.ok,false);
  const reset=await rpc('opengym_write_profile',{p_instance:'test',p_uid:a.body.user.id,p_state:{routines:[],workouts:[],resetAt:100,resetIds:{workouts:100}},p_base_rev:1});
  assert.equal(reset.ok,true);
  const stamp=await rpc('opengym_write_profile',{p_instance:'test',p_uid:a.body.user.id,p_state:{routines:[],workouts:[],resetAt:10},p_base_rev:2});
  assert.equal(stamp.state.resetAt,100);assert.equal(stamp.state.resetIds.workouts,100);
  const snapshot=await rpc('opengym_snapshot',{p_instance:'test'});
  await rpc('opengym_write_profile',{p_instance:'test',p_uid:a.body.user.id,p_state:{routines:[],workouts:[{id:'after-backup'}]},p_base_rev:3});
  assert.equal((await rpc('opengym_restore',{p_instance:'test',p_snapshot:snapshot,p_revision:row.revision})).ok,true);
  assert.equal((await pg.query("select state from public.opengym_profiles where instance_id='test' and user_id=$1",[a.body.user.id])).rows[0].state._rev,3);
  const next={...row.registry,users:row.registry.users.filter(u=>u.id!==a.body.user.id)};
  assert.equal((await rpc('opengym_save_registry',{p_instance:'test',p_registry:next,p_revision:row.revision+1})).ok,true);
  assert.equal((await pg.query("select user_id from public.opengym_profiles where instance_id='test' and user_id=$1",[a.body.user.id])).rows.length,0);
  console.log('PASS: SQL metadata CAS, monotonic reset stamps, atomic snapshot/restore and transactional account/state deletion.');
} finally {
  await stop();await new Promise(r=>bridge.close(r));await pg.close();rmSync(local,{recursive:true,force:true});
}
