import { pathToFileURL } from 'node:url';

// Render provides the final HTTPS URL. Use it unless the operator set a custom origin.
export function publicOrigin(env) {
  const raw = (env.ORIGIN || env.RENDER_EXTERNAL_URL || '').replace(/\/$/, '');
  let url;
  try { url = new URL(raw); } catch { throw new Error('缺少有效的公网 HTTPS 地址。'); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || url.pathname !== '/' || url.origin !== raw) {
    throw new Error('公网地址必须是 HTTPS 网站根地址，不可包含凭据、路径或参数。');
  }
  const rpId = env.RP_ID || url.hostname;
  if (rpId !== url.hostname) throw new Error('通行密钥域名必须与公网地址一致。');
  return { origin: url.origin, rpId };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try {
    const config = publicOrigin(process.env);
    const field = process.argv[2];
    if (!['origin', 'rpId'].includes(field)) throw new Error('请选择 origin 或 rpId。');
    process.stdout.write(config[field]);
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
