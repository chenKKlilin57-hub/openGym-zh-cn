import { cloudStoreFromEnv } from '../../api/supabase-store.js';
import { mkdir, writeFile, readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const [action, archive, confirm] = process.argv.slice(2);
const store=cloudStoreFromEnv();
if(!store) throw new Error('Requires DATA_BACKEND=supabase');
if(action==='backup') {
  const snapshot=await store.rpc('opengym_snapshot');
  await mkdir(new URL('../../backups/',import.meta.url),{recursive:true});
  const file=new URL('../../backups/opengym-cloud-'+new Date().toISOString().replace(/[:.]/g,'-')+'.json',import.meta.url);
  await writeFile(file,JSON.stringify(snapshot),{mode:0o600,flag:'wx'});
  console.log('云端数据库备份：',fileURLToPath(file));
} else if(action==='restore') {
  const instance=process.env.SUPABASE_INSTANCE||'main';
  if(!archive || confirm!=='--confirm-instance='+instance) throw new Error('先停止网站；恢复命令必须含 --confirm-instance='+instance);
  const snapshot=JSON.parse(await readFile(resolve(archive),'utf8'));
  if(snapshot.instance?.instance_id!==instance) throw new Error('备份实例与目标不一致，未恢复');
  const current=await store.rpc('opengym_snapshot');
  // Keep a recovery copy before invoking a deliberate restore.
  await mkdir(new URL('../../backups/',import.meta.url),{recursive:true});
  await writeFile(new URL('../../backups/before-cloud-restore-'+Date.now()+'.json',import.meta.url),JSON.stringify(current),{mode:0o600,flag:'wx'});
  const result=await store.rpc('opengym_restore',{p_snapshot:snapshot,p_revision:current.instance.revision});
  if(!result.ok) throw new Error('云端发生并发修改，未完成恢复；保持网站停止并重新检查');
  console.log('恢复完成；重新启动网站。');
} else throw new Error('Usage: node --env-file=.env.cloud private/cloud/backup.mjs backup | restore <archive> --confirm-instance=<name>');
