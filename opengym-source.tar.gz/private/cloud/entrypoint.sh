#!/usr/bin/env bash
set -euo pipefail
: "${SUPABASE_URL:?missing SUPABASE_URL}"
: "${SUPABASE_SECRET_KEY:?missing SUPABASE_SECRET_KEY}"
public_origin="$(node /app/public-origin.mjs origin)"
public_rp_id="$(node /app/public-origin.mjs rpId)"
export ORIGIN="$public_origin" RP_ID="$public_rp_id" API_HOST=127.0.0.1
export NGINX_PORT="${PORT:-10000}" BACKEND=127.0.0.1 PORT=3000 RESOLVER=1.1.1.1
# Render's public edge is Cloudflare. Keep the upstream nginx template's explicit
# CF header support; never trust a caller-supplied X-Forwarded-For first element.
export CF_CONNECTING_IP='$http_cf_connecting_ip' BASE_PATH='' MEDIA_UPLOAD_MAX=48m TRUST_PROXY=1
mkdir -p /var/data/api /var/data/media/img /var/data/media/gif /run/nginx /etc/nginx/http.d
ln -sfn /var/data/media /app/media
# Fetch at runtime from the unchanged upstream script; no copyrighted media in the image/repo.
if [[ ! -f /var/data/media/.fetched ]]; then
  timeout 600 bash /app/scripts/fetch-media.sh
  touch /var/data/media/.fetched
fi
ln -sfn /var/data/media/img /usr/share/nginx/html/img
ln -sfn /var/data/media/gif /usr/share/nginx/html/gif
envsubst '${NGINX_PORT} ${BACKEND} ${PORT} ${RESOLVER} ${CF_CONNECTING_IP} ${BASE_PATH} ${MEDIA_UPLOAD_MAX}' < /app/nginx.conf.template > /etc/nginx/http.d/default.conf
nginx -t
node /app/api/server.js &
api_pid=$!
nginx -g 'daemon off;' &
web_pid=$!
trap 'kill "$api_pid" "$web_pid" 2>/dev/null || true' EXIT TERM INT
# Exit if either service exits, so the host restarts the complete application.
set +e
wait -n "$api_pid" "$web_pid"
exit 1
