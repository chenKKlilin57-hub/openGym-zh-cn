-- openGym cloud storage v1. Run in the dedicated openGym project only.
-- Authentication stays in the Node API. Browser database roles get no access.
begin;

create table if not exists public.opengym_instances (
  instance_id text primary key check (instance_id ~ '^[A-Za-z0-9_-]{1,96}$'),
  registry jsonb not null default '{"users":[],"creds":[],"subs":[],"invites":[],"deviceLinks":[]}'::jsonb,
  revision bigint not null default 0 check (revision >= 0),
  session_secret text not null check (session_secret ~ '^[a-f0-9]{64}$'),
  vapid jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists public.opengym_profiles (
  instance_id text not null references public.opengym_instances(instance_id) on delete cascade,
  user_id text not null check (user_id ~ '^[A-Za-z0-9_-]{1,128}$'),
  state jsonb,
  revision bigint not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now(),
  primary key (instance_id, user_id)
);
alter table public.opengym_instances enable row level security;
alter table public.opengym_profiles enable row level security;
revoke all on public.opengym_instances, public.opengym_profiles from public, anon, authenticated;
grant select, insert, update, delete on public.opengym_instances, public.opengym_profiles to service_role;

create or replace function public.opengym_initialize(p_instance text, p_secret text, p_vapid jsonb)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare result jsonb;
begin
  insert into public.opengym_instances(instance_id,session_secret,vapid) values(p_instance,p_secret,p_vapid)
    on conflict(instance_id) do nothing;
  select to_jsonb(i) into result from public.opengym_instances i where i.instance_id=p_instance;
  return result;
end $$;

create or replace function public.opengym_save_registry(p_instance text, p_registry jsonb, p_revision bigint)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare current_revision bigint;
begin
  if jsonb_typeof(p_registry) is distinct from 'object'
    or jsonb_typeof(p_registry->'users') is distinct from 'array'
    or jsonb_typeof(p_registry->'creds') is distinct from 'array'
  then raise exception 'invalid registry'; end if;
  select revision into current_revision from public.opengym_instances where instance_id=p_instance for update;
  if not found then raise exception 'instance not initialized'; end if;
  if current_revision <> p_revision then return jsonb_build_object('ok',false,'revision',current_revision); end if;
  update public.opengym_instances set registry=p_registry,revision=revision+1,updated_at=now() where instance_id=p_instance;
  -- Account removal and its state removal are one transaction, never a partial delete.
  delete from public.opengym_profiles p where p.instance_id=p_instance
    and not exists(select 1 from jsonb_array_elements(p_registry->'users') u where u->>'id'=p.user_id);
  return jsonb_build_object('ok',true,'revision',current_revision+1);
end $$;

create or replace function public.opengym_write_profile(p_instance text, p_uid text, p_state jsonb, p_base_rev bigint default null)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare current_state jsonb; current_revision bigint; auth_registry jsonb; stored_reset numeric:=0; sent_reset numeric:=0;
begin
  if jsonb_typeof(p_state) is distinct from 'object' then raise exception 'invalid state'; end if;
  -- A registry delete cannot race between the owner check and the state commit.
  select registry into auth_registry from public.opengym_instances where instance_id=p_instance for share;
  if not found or not exists(select 1 from jsonb_array_elements(auth_registry->'users') u where u->>'id'=p_uid)
    then raise exception 'unknown profile'; end if;
  insert into public.opengym_profiles(instance_id,user_id) values(p_instance,p_uid) on conflict do nothing;
  select state,revision into current_state,current_revision from public.opengym_profiles
    where instance_id=p_instance and user_id=p_uid for update;
  if p_base_rev is not null and p_base_rev<>current_revision then
    return jsonb_build_object('ok',false,'rev',current_revision,'state',current_state);
  end if;
  -- Keep the upstream reset stamp monotonic, including writes racing on another API process.
  if coalesce(current_state->>'resetAt','') ~ '^[0-9]+([.][0-9]+)?$' then stored_reset:=(current_state->>'resetAt')::numeric; end if;
  if coalesce(p_state->>'resetAt','') ~ '^[0-9]+([.][0-9]+)?$' then sent_reset:=(p_state->>'resetAt')::numeric; end if;
  if stored_reset>sent_reset then
    p_state:=p_state||jsonb_build_object('resetAt',current_state->'resetAt');
    if jsonb_typeof(current_state->'resetIds') in ('object','array') then
      p_state:=p_state||jsonb_build_object('resetIds',current_state->'resetIds');
    else p_state:=p_state-'resetIds'; end if;
  end if;
  p_state:=(p_state-'active')||jsonb_build_object('_rev',current_revision+1);
  update public.opengym_profiles set state=p_state,revision=current_revision+1,updated_at=now()
    where instance_id=p_instance and user_id=p_uid;
  return jsonb_build_object('ok',true,'rev',current_revision+1,'state',p_state);
end $$;

create or replace function public.opengym_snapshot(p_instance text)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare instance_row jsonb; profile_rows jsonb;
begin
  -- Profile writers share this lock, so the snapshot cannot split a registry/state commit.
  select to_jsonb(i) into instance_row from public.opengym_instances i where instance_id=p_instance for update;
  if not found then raise exception 'instance not initialized'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('user_id',user_id,'state',state,'revision',revision)),'[]'::jsonb)
    into profile_rows from public.opengym_profiles where instance_id=p_instance;
  return jsonb_build_object('format','opengym-supabase-v1','instance',instance_row,'profiles',profile_rows,'created_at',now());
end $$;

create or replace function public.opengym_restore(p_instance text, p_snapshot jsonb, p_revision bigint)
returns jsonb language plpgsql security invoker set search_path = '' as $$
declare current_revision bigint; restored jsonb; item jsonb;
begin
  if p_snapshot->>'format' is distinct from 'opengym-supabase-v1'
    or p_snapshot->'instance'->>'instance_id' is distinct from p_instance
    or jsonb_typeof(p_snapshot->'profiles') is distinct from 'array'
    then raise exception 'invalid snapshot'; end if;
  restored:=p_snapshot->'instance';
  if jsonb_typeof(restored->'registry'->'users') is distinct from 'array'
    or jsonb_typeof(restored->'registry'->'creds') is distinct from 'array'
    then raise exception 'invalid snapshot registry'; end if;
  select revision into current_revision from public.opengym_instances where instance_id=p_instance for update;
  if not found then raise exception 'instance not initialized'; end if;
  if current_revision<>p_revision then return jsonb_build_object('ok',false); end if;
  update public.opengym_instances set registry=restored->'registry',session_secret=restored->>'session_secret',
    vapid=restored->'vapid',revision=current_revision+1,updated_at=now() where instance_id=p_instance;
  delete from public.opengym_profiles where instance_id=p_instance;
  for item in select value from jsonb_array_elements(p_snapshot->'profiles') loop
    if not exists(select 1 from jsonb_array_elements(restored->'registry'->'users') u where u->>'id'=item->>'user_id')
      then raise exception 'snapshot has an orphan profile'; end if;
    if item->'state' <> 'null'::jsonb and (item->'state'->>'_rev')::bigint is distinct from (item->>'revision')::bigint
      then raise exception 'snapshot revision mismatch'; end if;
    insert into public.opengym_profiles(instance_id,user_id,state,revision)
      values(p_instance,item->>'user_id',nullif(item->'state','null'::jsonb),(item->>'revision')::bigint);
  end loop;
  return jsonb_build_object('ok',true);
end $$;

revoke all on function public.opengym_initialize(text,text,jsonb),
  public.opengym_save_registry(text,jsonb,bigint),public.opengym_write_profile(text,text,jsonb,bigint),
  public.opengym_snapshot(text),public.opengym_restore(text,jsonb,bigint)
  from public,anon,authenticated;
grant execute on function public.opengym_initialize(text,text,jsonb),
  public.opengym_save_registry(text,jsonb,bigint),public.opengym_write_profile(text,text,jsonb,bigint),
  public.opengym_snapshot(text),public.opengym_restore(text,jsonb,bigint)
  to service_role;
notify pgrst, 'reload schema';
commit;
