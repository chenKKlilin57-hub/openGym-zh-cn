# openGym 中文云端版：本机网站 + Supabase

已按用户选择完成 Supabase 接入，暂时由这台 Mac 运行网站。当前正式入口为 http://localhost:8080/；账号、计划、已完成训练、体重和设置保存在用户自己的 Supabase 项目 [openGym-cloud](https://supabase.com/dashboard/project/gqfurtopojqrokdhciqz)，区域 Singapore。尚未部署公网网站，其他人还不能从外网访问这个 localhost 地址。

基于官方 v1.3.9 / `e6c920eb0a657e57139798f60da40c934aec9301`，云端代码在独立目录 `/Users/Zhuanz/Documents/Playground 2/openGym-cloud`、分支 `codex/supabase-cloud`。沿用官方 React/Vite 界面、中文语言包、训练逻辑、密码/通行密钥认证和动作 ID；不启用 AI，不更换前端框架，不增加运行依赖。

当前云端版已补齐 1,324 个内置动作名称，并检查全部 7,710 条中文动作说明、2,077 项界面词条及动态标签。默认中文不附加英文动作名称；设置中仍可主动开启英文。完整覆盖、验证记录和保留项见 [中文验收记录](../CHINESE_COVERAGE.md)。

## 使用

```sh
cd '/Users/Zhuanz/Documents/Playground 2/openGym-cloud'
python3 private/cloud/local.py start
python3 private/cloud/local.py status
python3 private/cloud/local.py stop
```

源码修改后执行 `python3 private/cloud/local.py build`，再停止、启动服务。Node.js 22+；本机已安装依赖和官方动作媒体。服务由 launchctl 管理，关闭终端或聊天不停止服务；电脑重启后需重新执行 start。网页和 API 都只监听本机回环地址。

| 环境 | 网址 | Supabase 命名空间 | 当前账号 |
| --- | --- | --- | --- |
| 正式云端版 | http://localhost:8080/ | main | 用户自建正式账号，与演示数据分开 |
| 云端演示版 | http://localhost:8082/ | demo | 云端验证 |
| 原版文件演示 | http://localhost:8081/ | 不使用 Supabase | 数据库验证 |

云端演示密码 `CloudDemo-Only-2026!R7q9`，仅用于虚拟测试资料；演示启停加 `--demo`。正式环境不导入演示账号。新注册的每个账号自动保存自己的数据，第一个正式账号沿用官方规则成为本网站管理员。

浏览器会话 Cookie 按主机名保存，不按端口隔离。云端演示 API 因此使用 `SESSION_COOKIE_SUFFIX=cloud_demo`，正式环境沿用官方名称；两个入口可同时登录，演示退出不会清除正式会话。原版 8081 的 Cookie 仍与正式环境同名，避免在原版演示和正式云端版来回登录。

## 数据保存在哪里

- Supabase PostgreSQL `public.opengym_instances`：网站账号和认证资料、会话/推送密钥；正式与演示按 `instance_id` 分开。
- `public.opengym_profiles`：以 `(instance_id, user_id)` 隔离的原版状态 JSONB，保存计划、训练历史、体重和设置；保留 `_rev` 和官方 409 冲突处理。
- 浏览器仍保留官方本地镜像和进行中的训练；进行中的 `active` 不上传，沿用官方行为。改动后自动提交云端；另一设备沿用前台返回检查和约 30 秒轮询。没有增加 Supabase Realtime WebSocket，不能称为两端瞬时联动。
- 自定义动作上传文件仍在本机 `.cloud-runtime/main/data/uploads/`（演示为 demo），不在 PostgreSQL 中。官方图片/GIF 沿用原下载方式和本地缓存，未重新分发。
- `.env.cloud` 是后端秘密配置，权限 0600，Git 和 Docker 上下文忽略；前端不包含 Supabase 秘密密钥。运行日志与 launchctl 配置在 `.cloud-runtime/main/`、`.cloud-runtime/demo/`，配置含密钥，勿公开。

两张表开启 RLS，匿名/普通数据库角色不能读写表或调用相关函数。现有账号认证属于 openGym，不是 Supabase Auth，因此 Dashboard 的 Authentication 用户数为零是正常的；账号可在受保护的实例记录里查看。网页只通过验证身份的 Node API 访问云端，用户 ID 取自会话。数据库不可用时 API 返回 503，不能静默转成本地保存并宣称成功。

## 备份与恢复

云端一致性备份（可以在线执行，含账号、训练、认证与密钥，文件权限 0600）：

```sh
node --env-file=.env.cloud private/cloud/backup.mjs backup
```

文件生成在本目录 `backups/`。请另外保存一份到安全位置；不要分享备份内容。演示备份可在命令前加 `SUPABASE_INSTANCE=demo`。

恢复会把目标环境恢复到快照时的内容，先停止该环境。恢复程序会额外保留恢复前的云端快照，校验命名空间和并发版本，并在一个数据库事务中恢复：

```sh
python3 private/cloud/local.py stop
node --env-file=.env.cloud private/cloud/backup.mjs restore '/绝对路径/备份.json' --confirm-instance=main
python3 private/cloud/local.py start
```

有自定义上传媒体时，还需单独备份 `.cloud-runtime/main/data/`。停机后例如：

```sh
tar -czf backups/opengym-cloud-local-files.tar.gz -C .cloud-runtime/main data
chmod 600 backups/opengym-cloud-local-files.tar.gz
```

恢复上传文件时先停机，保留现有 data 目录，再还原这份自己生成的压缩包。数据库备份不包含上传媒体。

## 原版保留与当前限制

原版 `/Users/Zhuanz/Documents/Playground 2/openGym` 的代码、JSON 数据和演示环境保留。原版正式服务已停止，以释放 8080；切换前确认正式账号数为 0，并保存备份 `openGym/backups/opengym-private-20261005-003457-071087.tar.gz`。若需切回原版，先停止云端 main，再在原版目录执行 `python3 private/local.py start`；两版数据库不自动互相迁移。

当前以单个 Node API 进程运行，适合本机验证和小规模使用；多实例扩容需另行处理官方内存挑战、计时器和账号注册表并发。电脑关闭时网站不可访问，已经提交到 Supabase 的数据保留。Supabase Free 项目长期低活动可能暂停，需要在 Dashboard 恢复；参见 [官方免费项目说明](https://supabase.com/docs/guides/platform/free-project-pausing)。

公网部署准备：`private/cloud/render.yaml` 使用新加坡 Starter 与 1 GB 持久盘；入口自动读取 Render 的 HTTPS 地址并校验通行密钥域名，下载官方媒体成功后写入完成标记，API 仅绑定回环地址。健康检查不再排队等待慢上传。运行 `python3 private/cloud/package-source.py` 可生成排除密钥、训练数据、备份、依赖和第三方媒体的完整源码快照及 GitHub 网页上传文件，输出在被忽略的 `.cloud-runtime/publish/`。

当前尚未创建 Render 服务、产生托管订阅或发布公网网站。本机未安装 Docker，镜像仍需在托管构建中验证。源包的 Dockerfile 先解压源码，再运行同一 Node API + nginx 构建，不改应用架构。公开服务走 Cloudflare，沿用原模板的客户端 IP 头支持；首次部署需验证平台覆盖伪造 IP 头，同工作区私网仅容纳可信服务。

## 验证结果

- 真实 Supabase：两用户注册和隔离、未登录拒绝、伪造用户 ID 无效、旧版本 409、更新/删除、API 重启后会话和训练保留、事务备份/恢复通过。独立 integration 测试命名空间已清理，正式环境无测试用户。
- 真实 Supabase 公开 publishable key：两张表和快照函数返回数据库权限拒绝（42501），无账号或训练内容泄露。
- 网页演示账号登录、历史记录读取通过；网页新增虚拟体重 70.5 kg，直接查询真实 Supabase 确认已保存。
- 更新中文界面前导出浏览器备份，重新登录同一演示账号并合并 3 项待同步更改。网页显示“已全部同步”；真实 Supabase 中的 3 个计划、3 次训练及体重与浏览器备份完全一致。
- 独立 PostgreSQL/PGlite：SQL 编译、权限、断连时 503、事务版本冲突、删除账号同步删除状态、备份恢复通过。
- 存储单测 5/5 通过。涉及管理员、媒体、提醒、请求体和状态缓存的回归 51 项最终通过（其中 2 项修正原版日志文字后重测通过）。
- 文件模式数据版本/重置/密码组 29/31；另 2 项为原版已存在的密码并发限流 429/200 时序失败。v0.1 前端原有演示 Coach 测试失败详情见 `private/TEST_RESULTS.md`；本次前端构建和中文完整性检查通过。
- 完整前端测试 3,179/3,180 通过，唯一失败仍为已在原版复现的 `CoachChat.demo-failure.test.jsx`；中文最终针对性测试 136/136 通过，服务器配置与会话隔离测试 5/5 通过。详情见中文验收记录。

关键文件：`api/supabase-store.js`、`api/server.js`、`private/cloud/schema.sql`、`private/cloud/local.py`、`private/cloud/backup.mjs`。官方 LICENSE、NOTICE 和媒体获取脚本保持不变。
