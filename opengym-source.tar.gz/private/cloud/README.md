# openGym 中文云端版：Render + Supabase

正式入口：**https://opengym-zh-cn.onrender.com/**。源码仓库：[openGym-zh-cn](https://github.com/chenKKlilin57-hub/openGym-zh-cn)。网站已在新加坡 Render Free 完成首次 Docker 构建并上线；账号、计划、已完成训练、体重和设置继续保存在现有 Supabase 项目，正式命名空间为 `main`。

基于[官方 openGym](https://github.com/DuarteSantos8/openGym) v1.3.9 / `e6c920eb0a657e57139798f60da40c934aec9301`，首次上线代码提交为 `7de6e28505e0d9fd3d156c27d3f01c47b411e85f`。沿用官方 React/Vite 界面、中文语言包、训练逻辑、密码/通行密钥认证和动作 ID；不启用 AI，不更换前端框架，不增加运行依赖。

当前云端版已补齐 1,324 个内置动作名称，并检查全部 7,710 条中文动作说明、2,077 项界面词条及动态标签。默认中文不附加英文动作名称；设置中仍可主动开启英文。完整覆盖、验证记录和保留项见 [中文验收记录](../CHINESE_COVERAGE.md)。

## 访问与维护

日常使用直接访问正式入口。本机正式 `main` 服务已停止；电脑关闭不影响 Render 网站或已提交到 Supabase 的数据。本机演示入口 http://localhost:8082/ 保留，使用独立的 `demo` 命名空间，不与正式数据混用。

开放注册已生效：`INVITE_ONLY=0` 的配置部署已 Live，公网 `/api/config` 返回 `invite_only: false`，允许密码登录、关闭游客并默认简体中文。维护时在 Render 查看部署状态与运行日志，并确认 HTTPS `/api/health` 返回 200、`/api/config` 的 `invite_only` 符合预期；健康响应只表示进程存活，不代替数据端点的数据库连接检查。

当前关闭自动部署。更新源码后重新生成并提交完整源码包及根目录构建文件，再在 Render 手动部署对应提交；不要只修改公开仓库中的说明而漏更新实际构建使用的源码包。`private/cloud/render.yaml` 使用 `plan: free`、Singapore、`/api/health`，无持久盘。秘密密钥只放在 Render 后台环境变量，不写入公开仓库、源码包或前端。

Render Free 会在空闲后休眠，再次访问需要等待唤醒。服务休眠、重启或重新部署会丢失本地文件，包括自定义动作上传文件和官方媒体缓存；下一次启动会沿用官方脚本重新下载媒体。账号、计划、训练历史、体重和设置由 Supabase 保存，不依赖这些本地文件。参见 [Render Free 说明](https://render.com/docs/free)。

**同一 Supabase 命名空间只能运行一个正式 API 实例。** 不要同时运行 Render 和本机 `main`；回切本机前必须先暂停 Render，恢复云端前必须先停止本机 `main`。演示环境 `demo` 可以独立运行。

## 数据保存在哪里

- Supabase PostgreSQL `public.opengym_instances`：网站账号和认证资料、会话/推送密钥；正式与演示按 `instance_id` 分开。
- `public.opengym_profiles`：以 `(instance_id, user_id)` 隔离的原版状态 JSONB，保存计划、训练历史、体重和设置；保留 `_rev` 和官方 409 冲突处理。
- 浏览器仍保留官方本地镜像和进行中的训练；进行中的 `active` 不上传，沿用官方行为。改动后自动提交云端；另一设备沿用前台返回检查和约 30 秒轮询。没有增加 Supabase Realtime WebSocket，不能称为两端瞬时联动。
- Render 上的自定义动作上传文件在 `/var/data/api/uploads/`，不在 PostgreSQL 中，Free 实例不保证保存。原本机文件仍在 `.cloud-runtime/main/data/uploads/`（演示为 demo），没有随源码上传至 Render；本机上传与线上上传不会自动互相复制。官方图片/GIF 沿用原下载方式和本地缓存，未重新分发。
- `.env.cloud` 是后端秘密配置，权限 0600，Git 和 Docker 上下文忽略；前端不包含 Supabase 秘密密钥。运行日志与 launchctl 配置在 `.cloud-runtime/main/`、`.cloud-runtime/demo/`，配置含密钥，勿公开。

两张表开启 RLS，匿名/普通数据库角色不能读写表或调用相关函数。现有账号认证属于 openGym，不是 Supabase Auth，因此 Dashboard 的 Authentication 用户数为零是正常的；账号可在受保护的实例记录里查看。网页只通过验证身份的 Node API 访问云端，用户 ID 取自会话。数据库不可用时 API 返回 503，不能静默转成本地保存并宣称成功。

## 备份与恢复

云端一致性备份（可以在线执行，含账号、训练、认证与密钥，文件权限 0600）：

```sh
node --env-file=.env.cloud private/cloud/backup.mjs backup
```

文件生成在本目录 `backups/`。请另外保存一份到安全位置；不要分享备份内容。演示备份可在命令前加 `SUPABASE_INSTANCE=demo`。

恢复会把目标环境恢复到快照时的内容。先暂停 Render 正式服务，并确认本机 `main` 已停止；恢复程序会额外保留恢复前的云端快照，校验命名空间和并发版本，并在一个数据库事务中恢复：

```sh
python3 private/cloud/local.py stop
node --env-file=.env.cloud private/cloud/backup.mjs restore '/绝对路径/备份.json' --confirm-instance=main
```

恢复完成后只恢复 Render 或回切本机其中一个正式实例。

有自定义上传媒体时，还需单独备份 `.cloud-runtime/main/data/`。停机后例如：

```sh
tar -czf backups/opengym-cloud-local-files.tar.gz -C .cloud-runtime/main data
chmod 600 backups/opengym-cloud-local-files.tar.gz
```

恢复上传文件时先停机，保留现有 data 目录，再还原这份自己生成的压缩包。数据库备份不包含上传媒体。

## 回切本机

先在 Render 暂停正式云端服务，再在本项目目录执行以下命令。本机依赖 Node.js 22+ 和本地后端环境配置；不要将后端环境文件公开。

```sh
python3 private/cloud/local.py start
python3 private/cloud/local.py status
python3 private/cloud/local.py stop
```

回切后本机正式入口为 http://localhost:8080/。源码修改后执行 `python3 private/cloud/local.py build`，再停止、启动本机服务。服务由 launchctl 管理，关闭终端或聊天不停止服务；电脑重启后需重新执行 start。演示启停加 `--demo`。演示 API 使用独立会话 Cookie 后缀；本机原版文件模式环境与正式环境的同名 Cookie 可能互相影响，避免交替登录。

恢复线上服务前先执行本机 `stop`，再恢复 Render。原版文件模式代码、JSON 数据和演示环境保留；原版与 Supabase 版数据库不自动互相迁移。

## 源码与当前限制

公开仓库中的 `opengym-source.tar.gz` 是完整可修改源码，解压保留原目录、中文词条、Node API、Supabase 适配、构建和测试脚本。根目录 Dockerfile 先解压源包，再执行同一 Node API + nginx 构建。运行 `python3 private/cloud/package-source.py` 生成下一份排除密钥、训练数据、备份、依赖和第三方媒体的源码快照及网页上传文件，输出在被忽略的 `.cloud-runtime/publish/`。

入口自动读取 Render HTTPS 地址并校验通行密钥域名，官方媒体下载成功后写入完成标记，API 仅绑定回环地址。健康检查不排队等待慢上传。当前为单个 Node API 进程；多实例扩容需另行处理官方内存挑战、计时器和账号注册表并发。Supabase Free 项目长期低活动可能暂停，需要在 Dashboard 恢复；参见 [官方免费项目说明](https://supabase.com/docs/guides/platform/free-project-pausing)。

## 验证结果

- 线上 Render Docker 构建和开放注册配置重启均已 Live；官方脚本下载 1,324 张动作图片和 1,324 个 GIF 成功。公网健康与配置接口 200，未登录读取训练数据 401，图片与 GIF 地址 200，公开源码下载 200 且与上传源包一致。
- 重启后实际 Supabase 快照与部署前备份比较：正式训练资料、密码认证资料及会话密钥均未改变，已有正式账号仍为 1 个。正式环境没有创建测试用户；未验证正式账号的密码登录。
- 线上伪造 `CF-Connecting-IP` 的请求返回 403；伪造 `X-Forwarded-For` 不能绕过设备绑定的 `link` 限流。不同真实出口是否被正确区分仍未验证，不能据此声称完整客户端 IP 分桶已通过。
- 真实 Supabase：两用户注册和隔离、未登录拒绝、伪造用户 ID 无效、旧版本 409、更新/删除、API 重启后会话和训练保留、事务备份/恢复通过。独立 integration 测试命名空间已清理，正式环境无测试用户。
- 真实 Supabase 公开 publishable key：两张表和快照函数返回数据库权限拒绝（42501），无账号或训练内容泄露。
- 网页演示账号登录、历史记录读取通过；网页新增虚拟体重 70.5 kg，直接查询真实 Supabase 确认已保存。
- 更新中文界面前导出浏览器备份，重新登录同一演示账号并合并 3 项待同步更改。网页显示“已全部同步”；真实 Supabase 中的 3 个计划、3 次训练及体重与浏览器备份完全一致。
- 独立 PostgreSQL/PGlite：SQL 编译、权限、断连时 503、事务版本冲突、删除账号同步删除状态、备份恢复通过。
- 存储单测 5/5 通过。涉及管理员、媒体、提醒、请求体和状态缓存的回归 51 项最终通过（其中 2 项修正原版日志文字后重测通过）。
- 文件模式数据版本/重置/密码组 29/31；另 2 项为原版已存在的密码并发限流 429/200 时序失败。v0.1 前端原有演示 Coach 测试失败详情见 `private/TEST_RESULTS.md`；本次前端构建和中文完整性检查通过。
- 完整前端测试 3,179/3,180 通过，唯一失败仍为已在原版复现的 `CoachChat.demo-failure.test.jsx`；中文最终针对性测试 136/136 通过，服务器配置与会话隔离测试 5/5 通过。详情见中文验收记录。

关键文件：`api/supabase-store.js`、`api/server.js`、`private/cloud/schema.sql`、`private/cloud/local.py`、`private/cloud/backup.mjs`。代码遵循原 AGPL-3.0-or-later；上游作者版权、官方 LICENSE、NOTICE 和媒体获取脚本保留。动作媒体仍须遵守权利人授权，不包含在公开源码包中。
