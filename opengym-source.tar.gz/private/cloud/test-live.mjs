// Real Supabase integration, isolated in a disposable test namespace.
import { cloudStoreFromEnv } from '../../api/supabase-store.js';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { boundPort } from '../../api/test/helpers.mjs';
const root=dirname(dirname(dirname(fileURLToPath(import.meta.url))));
const instance='integration-'+Date.now();
const env={...process.env,SUPABASE_INSTANCE:instance,NODE_ENV:'test',PORT:'0',ORIGIN:'http://localhost:8082',RP_ID:'localhost'};
const store=cloudStoreFromEnv(env);
if(!store) throw new Error('Load .env.cloud first');
const local=mkdtempSync(join(tmpdir(),'opengym-live-cloud-'));
let child;let api;
async function start(){
  let log='';
  child=spawn(process.execPath,['server.js'],{cwd:join(root,'api'),env:{...env,DATA_DIR:local},stdio:['ignore','pipe','pipe']});
  child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);
  api=`http://127.0.0.1:${await boundPort(child,()=>log)}`;
}
async function stop(){if(child&&child.exitCode===null){const done=new Promise(r=>child.once('exit',r));child.kill();await done;}}
async function request(route,{method='GET',body,cookie}={}){
  const r=await fetch(api+route,{method,headers:{Origin:env.ORIGIN,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},...(body?{body:JSON.stringify(body)}:{})});
  return {status:r.status,body:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
}
try {
  await start();
  const password='Disposable-cloud-test-2026!8T';
  const [a,b]=await Promise.all(['云端测试 A','云端测试 B'].map(name=>request('/api/register/password',{method:'POST',body:{name,password}})));
  assert.equal(a.status,200);assert.equal(b.status,200);
  const state={lang:'zh',routines:[{id:'routine1',name:'云端数据库测试',ex:[{id:'0025',sets:3,reps:10,weight:60}]}],workouts:[{id:'w1',d:'2026-10-04',name:'云端数据库测试',vol:1620,prs:['0025'],entries:[{id:'0025',sets:[10,9,8].map(r=>({w:60,r,done:true}))}]}],bodyweight:[{d:'2026-10-04',w:70}],active:{id:'local-only'}};
  const put=(account,body,baseRev)=>request('/api/data',{method:'PUT',cookie:account.cookie,body:{state:body,baseRev}});
  assert.equal((await put(a,state,0)).status,200);
  assert.equal((await put(b,{lang:'zh',routines:[{id:'B',name:'B 私人计划'}],workouts:[]},0)).status,200);
  assert.equal((await request('/api/data?user_id='+b.body.user.id,{cookie:a.cookie})).body.state.routines[0].id,'routine1');
  assert.equal((await request('/api/admin/user?id='+a.body.user.id,{cookie:b.cookie})).status,403);
  assert.equal((await request('/api/data')).status,401);
  assert.equal((await put(a,{...state,workouts:[]},0)).status,409);
  const snapshot=await store.rpc('opengym_snapshot');
  assert.equal(snapshot.instance.registry.users.length,2);
  assert.equal(snapshot.profiles.find(p=>p.user_id===a.body.user.id).state.workouts[0].vol,1620);
  assert.equal(snapshot.profiles.find(p=>p.user_id===a.body.user.id).state.active,undefined);
  const before=await store.loadState(a.body.user.id);
  const modified={...before,workouts:[{...before.workouts[0],note:'真实 Supabase 修改验证'}]};
  assert.equal((await put(a,modified,1)).status,200);
  const deleted={...modified,routines:[]};
  assert.equal((await put(a,deleted,2)).status,200);
  assert.equal((await store.loadState(a.body.user.id)).routines.length,0);
  await stop();await start();
  const restoredSession=await request('/api/data',{cookie:a.cookie});
  assert.equal(restoredSession.status,200);
  assert.equal(restoredSession.body.state.workouts[0].note,'真实 Supabase 修改验证');
  const login=await request('/api/login/password',{method:'POST',body:{name:'云端测试 B',password}});
  assert.equal(login.status,200);
  assert.equal((await request('/api/data',{cookie:login.cookie})).body.state.routines[0].id,'B');
  assert.equal(readdirSync(local).some(n=>n==='secret'||n==='db.json'||n.startsWith('state-')),false);
  await stop();
  const current=await store.rpc('opengym_snapshot');
  assert.equal((await store.rpc('opengym_restore',{p_snapshot:snapshot,p_revision:current.instance.revision})).ok,true);
  await start();
  const recovered=await request('/api/data',{cookie:a.cookie});
  assert.equal(recovered.status,200);
  assert.equal(recovered.body.state.routines[0].id,'routine1');
  assert.equal(recovered.body.state.workouts[0].note,undefined);
  assert.equal(recovered.body.state._rev,1);
  const denied=await fetch(env.SUPABASE_URL+'/rest/v1/opengym_instances?select=instance_id');
  assert.ok([401,403].includes(denied.status));
  console.log('PASS: real Supabase multi-account registration, isolation, conditional writes, updates/deletes, restart/session persistence and atomic snapshot/restore.');
  console.log('PASS: cloud contains the 60 kg × 10/9/8 workout; local auth/state files absent; unauthenticated database access denied.');
} finally {
  await stop();
  // Only this script's freshly created namespace is removed; main/demo are untouched.
  const key=env.SUPABASE_SECRET_KEY||env.SUPABASE_SERVICE_ROLE_KEY;
  const r=await fetch(env.SUPABASE_URL+'/rest/v1/opengym_instances?instance_id=eq.'+instance,{method:'DELETE',headers:{apikey:key,...(key.startsWith('sb_secret_')?{}:{Authorization:'Bearer '+key})}});
  if(!r.ok) console.error('测试命名空间清理失败，请检查：'+instance);
  rmSync(local,{recursive:true,force:true});
}
