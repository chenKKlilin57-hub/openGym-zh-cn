import { test } from 'node:test';
import assert from 'node:assert/strict';
import { publicOrigin } from './public-origin.mjs';

test('Render URL supplies the exact HTTPS origin and passkey hostname', () => {
  assert.deepEqual(publicOrigin({ RENDER_EXTERNAL_URL: 'https://opengym-example.onrender.com' }), {
    origin: 'https://opengym-example.onrender.com', rpId: 'opengym-example.onrender.com'
  });
});

test('explicit custom origin wins and an optional trailing slash is normalized', () => {
  assert.deepEqual(publicOrigin({ ORIGIN: 'https://gym.example.com/', RP_ID: 'gym.example.com', RENDER_EXTERNAL_URL: 'https://example.onrender.com' }), {
    origin: 'https://gym.example.com', rpId: 'gym.example.com'
  });
});

test('rejects an insecure origin, credentials, subpaths, parameters and mismatched passkey ID', () => {
  for (const ORIGIN of ['', 'http://gym.example.com', 'https://name:secret@gym.example.com', 'https://gym.example.com/path', 'https://gym.example.com?x=1', 'https://gym.example.com/#x']) {
    assert.throws(() => publicOrigin({ ORIGIN }));
  }
  assert.throws(() => publicOrigin({ ORIGIN: 'https://gym.example.com', RP_ID: 'other.example.com' }));
});

test('configuration errors never echo credentials or untrusted URL content', () => {
  const secret = 'credential-that-must-stay-private';
  assert.throws(() => publicOrigin({ ORIGIN: `https://name:${secret}@example.com` }), error => !error.message.includes(secret));
});
