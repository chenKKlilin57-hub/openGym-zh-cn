# 训练日历改进（2026-10-26）

本地实现完成，尚未部署到 Render。

- 统计页标题旁新增“训练日历”按钮，“本月”统计卡片也直接打开日历。
- 首页原连续训练卡片改为原生按钮，并显示“训练日历”文字。
- 日期格按当天已完成正式组的动作主肌群显示训练标签，合并同日多次训练；中文显示胸、肩、背、臂、核心、腿、有氧。
- 优先使用历史动作快照，兼容自定义动作。无法识别时显示原训练名称。不修改训练数据。
- 格内显示两个标签，更多部位显示 +N；辅助技术名称和悬浮提示包含完整类型及训练名称。
- 保留当天详情、计划安排和月份切换。修正日期字符串以本地中午解析，避免时区偏移到其他月份。

验证：生产构建通过；中文完整性 2129 项通过；calendar-labels.test.js 的 6 项测试通过。393×852 浏览器布局检查：文档宽度393、日历宽度357，无横向溢出。截图位于 private/screenshots/calendar-mobile-preview.jpg，使用独立示例数据。

DOM 回归测试尚未完成：默认 forks worker 启动超时，threads 模式工作进程长时间未响应；已停止卡住的测试进程。待环境恢复后执行：

```sh
cd frontend
node node_modules/vitest/vitest.mjs run --pool=threads --maxWorkers=1 src/lib/calendar-labels.test.js src/sheets.calendar.test.jsx src/views/Home.startdoor.test.jsx src/views/Stats.speed.test.jsx src/views/Stats.recovery.test.jsx
```

本次未改变数据库、账号、云端配置或现有服务。尚未发布，手机正式网址仍是原版本。
