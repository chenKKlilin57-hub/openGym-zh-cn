# 桌面图标

按用户提供的黑底荧光绿图案替换网页 App 桌面图标。使用内置 imagegen 编辑工具移除白色外边框、延伸黑色背景，保留图案和渐变；用系统 `sips` 导出 180、192、512 像素 PNG。iPhone 会自行应用圆角。

源图：`app-icon-neon-v1.png`。网页引用 `frontend/public/icon-180-neon-v1.png`、`icon-192-neon-v1.png`、`icon-512-neon-v1.png`；版本化文件名避免旧图缓存。上游旧图保留供已有引用使用。

编辑提示词：

> Use case: precise-object-edit. Asset type: production iPhone home-screen app icon. Input image is the edit target and must be preserved as faithfully as possible. Prepare this exact black and neon lime/yellow-green symbol as a full-bleed square icon. Remove only the white outer margin surrounding the rounded black square, and extend the black background to all four square edges and square corners (the operating system will apply its own rounded corners). Preserve the exact green symbol shape, proportions, direction, position relative to the black square, its lime-to-yellow gradient, and the subtle black background texture. No redesign, no new lettering, no text, no shadow around the icon, no white border, no extra elements, no perspective. Crisp 1024x1024 square PNG, opaque black corners, clean small-size readability.

网站更新不会保证 iOS 自动刷新已有主屏幕图标。需要时仅移除旧主屏幕入口，重新用 Safari 添加；不要清除网站数据或删除个人资料。
