| from | to | note |
| --- | --- | --- |
| barbell | 杠铃 | |
| dumbbell | 哑铃 | |
| cable | 绳索 | |
| lever | 器械 | 固定器械，保留片载/插片区别 |
| smith | 史密斯 | |
| kettlebell | 壶铃 | |
| band | 弹力带 | |
| resistance band | 弹力带 | |
| EZ bar | 曲杆杠铃 | |
| trap bar | 六角杠铃 | |
| bench press | 卧推 | |
| fly | 飞鸟 | |
| pullover | 仰卧上拉 | 按姿势和器械调整 |
| row | 划船 | |
| curl | 弯举 | 腿弯举、腕弯举按部位区分 |
| deadlift | 硬拉 | |
| squat | 深蹲 | |
| lunge | 弓步 | |
| clean | 翻举 | clean and jerk=挺举 |
| snatch | 抓举 | |
| jerk | 上挺 | |
| press | 推举 | 胸推/腿举按动作区分 |
| neutral grip | 对握 | |
| reverse grip | 反握 | |
| supinated | 掌心向上 | |
| pronated | 掌心向下 | |
| unilateral | 单侧 | |
| alternating | 交替 | |
| assisted | 辅助 | |
| weighted | 负重 | |
| incline | 上斜 | |
| decline | 下斜 | |
| stability ball | 瑞士球 | |
| bosu ball | 半球平衡球 | |
| medicine ball | 药球 | |
| RPE | RPE | 用户要求保留 |
| RIR | RIR | 用户要求保留 |
| PR | PR | 用户要求保留 |
| kg | kg | 用户要求保留 |
| lb | lb | 用户要求保留 |
