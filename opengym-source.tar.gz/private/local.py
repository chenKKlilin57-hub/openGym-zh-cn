#!/usr/bin/env python3
"""macOS lifecycle for the unchanged Node API and built Vite frontend."""
import argparse
import datetime
import os
import pathlib
import plistlib
import shutil
import subprocess
import sys
import tarfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description='openGym 中文私人版（macOS 本地运行）')
parser.add_argument('action', choices=['start', 'stop', 'status', 'build', 'backup', 'restore'])
parser.add_argument('--demo', action='store_true', help='隔离的测试数据库，端口 8081')
parser.add_argument('--archive', type=pathlib.Path, help='恢复的备份文件')
args = parser.parse_args()
MODE = 'demo' if args.demo else 'private'
RUNTIME = ROOT / '.private-runtime' / MODE
DATA = ROOT.parent / 'opengym-demo-data' if args.demo else ROOT / 'data'
LABEL = f'local.opengym.{MODE}'
DOMAIN = f'gui/{os.getuid()}'
PORT = 8081 if args.demo else 8080
API_PORT = 3001 if args.demo else 3000
RUNTIME.mkdir(parents=True, exist_ok=True)

def call(*cmd, check=True):
    return subprocess.run(cmd, check=check, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def loaded(name):
    return call('launchctl', 'print', f'{DOMAIN}/{LABEL}.{name}', check=False).returncode == 0

def stop():
    for name in ['web', 'api', 'media']:
        if loaded(name):
            call('launchctl', 'bootout', f'{DOMAIN}/{LABEL}.{name}')

def config():
    env = {k: os.environ[k] for k in ['PATH', 'HOME', 'LANG', 'TZ'] if k in os.environ}
    path = ROOT / '.env'
    if not path.exists():
        raise SystemExit('缺少 .env；请先按照 PRIVATE_ZH_CN.md 建立配置。')
    for line in path.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith('#') and '=' in line:
            k, v = line.split('=', 1)
            env[k.strip()] = v.strip().strip('"').strip("'")
    env.update(DATA_DIR=str(DATA), PORT=str(API_PORT), ORIGIN=f'http://localhost:{PORT}',
               RP_ID='localhost', API_ORIGIN=f'http://localhost:{PORT}',
               API_TARGET=f'http://127.0.0.1:{API_PORT}', MEDIA_TARGET=f'http://127.0.0.1:{8889 if args.demo else 8888}',
               COACH_DISABLED='1')
    # Vite and media bind to loopback; the unchanged API uses its official listener.
    return env

def build():
    subprocess.run(['npm', 'run', 'build'], cwd=ROOT / 'frontend', check=True,
                   env={**os.environ, 'APP_BUILD': 'zh-cn-v0.1'})

if args.action == 'build':
    build()
elif args.action == 'start':
    node = shutil.which('node')
    if not node:
        raise SystemExit('需要 Node.js（官方使用 Node 22）。')
    if not (ROOT / 'frontend/dist/index.html').exists():
        build()
    if not (ROOT / 'api/node_modules').exists():
        raise SystemExit('请先在 api/ 执行 npm ci --omit=optional。')
    if not any((ROOT / 'media/img').glob('*.jpg')):
        raise SystemExit('动作媒体未下载；已有授权时运行 bash scripts/fetch-media.sh。')
    DATA.mkdir(parents=True, exist_ok=True)
    env = config()
    media_port = 8889 if args.demo else 8888
    services = {
        'api': ([node, 'server.js'], ROOT / 'api'),
        'web': ([node, str(ROOT / 'frontend/node_modules/vite/bin/vite.js'), 'preview',
                 '--host', '127.0.0.1', '--port', str(PORT), '--strictPort'], ROOT / 'frontend'),
        'media': ([sys.executable, '-m', 'http.server', str(media_port), '--bind', '127.0.0.1',
                   '--directory', str(ROOT / 'media')], ROOT),
    }
    # Prevent adopting or interfering with another application's listeners.
    import socket
    for name, port in [('api', API_PORT), ('web', PORT), ('media', media_port)]:
        if loaded(name):
            continue
        with socket.socket() as sock:
            if sock.connect_ex(('127.0.0.1', port)) == 0:
                raise SystemExit(f'端口 {port} 已被占用；未停止其他进程。')
    for name, (command, cwd) in services.items():
        if loaded(name):
            continue
        path = RUNTIME / f'{name}.plist'
        record = dict(Label=f'{LABEL}.{name}', ProgramArguments=command,
                      WorkingDirectory=str(cwd), EnvironmentVariables=env,
                      RunAtLoad=True, KeepAlive=True,
                      StandardOutPath=str(RUNTIME / f'{name}.log'),
                      StandardErrorPath=str(RUNTIME / f'{name}.err.log'))
        path.write_bytes(plistlib.dumps(record))
        path.chmod(0o600)
        call('launchctl', 'bootstrap', DOMAIN, str(path))
    import time
    import urllib.request
    for attempt in range(50):
        try:
            with urllib.request.urlopen(f'http://localhost:{PORT}/api/health', timeout=2) as r:
                if r.status == 200:
                    print(f'已启动： http://localhost:{PORT} （{MODE}，数据：{DATA}）')
                    break
        except (OSError, ValueError):
            time.sleep(.2)
    else:
        raise SystemExit(f'启动未通过健康检查；查看 {RUNTIME} 下的日志。')
elif args.action == 'stop':
    stop()
    print(f'已停止 {MODE}；数据保留在 {DATA}')
elif args.action == 'status':
    for name in ['api', 'web', 'media']:
        print(name, '已加载' if loaded(name) else '已停止')
    print('数据目录：', DATA)
elif args.action == 'backup':
    if loaded('api'):
        raise SystemExit('请先执行 stop（demo 加 --demo），再备份以得到一致的快照。')
    if not DATA.exists():
        raise SystemExit('数据目录尚不存在。')
    destination = ROOT / 'backups'
    destination.mkdir(exist_ok=True)
    archive = destination / f'opengym-{MODE}-{datetime.datetime.now():%Y%m%d-%H%M%S-%f}.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(DATA, arcname='data', filter=lambda info: None if info.name == 'data/test-login.json' else info)
    archive.chmod(0o600)
    print('备份：', archive)
elif args.action == 'restore':
    if loaded('api'):
        raise SystemExit('请先执行 stop（demo 加 --demo），再恢复。')
    if not args.archive:
        raise SystemExit('恢复需要 --archive /绝对路径/备份.tar.gz')
    # Extract before moving existing data; reject traversal and symlinks.
    import tempfile
    with tempfile.TemporaryDirectory(dir=ROOT, prefix='.restore-') as folder:
        with tarfile.open(args.archive) as tar:
            for member in tar.getmembers():
                parts = pathlib.PurePosixPath(member.name).parts
                if not parts or parts[0] != 'data' or '..' in parts or member.issym() or member.islnk():
                    raise SystemExit('备份包含无效路径；未修改现有数据。')
            tar.extractall(folder, filter='data')
        restored = pathlib.Path(folder) / 'data'
        if not (restored / 'secret').is_file():
            raise SystemExit('备份不完整：缺少 secret；未修改现有数据。')
        if DATA.exists():
            saved = DATA.with_name(DATA.name + '.before-restore-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
            DATA.rename(saved)
            print('恢复前的数据保留在：', saved)
        try:
            shutil.move(str(restored), str(DATA))
        except BaseException:
            if 'saved' in locals() and not DATA.exists():
                saved.rename(DATA)
            raise
    print('已恢复：', DATA, '；执行 start 启动。')
