// Focus on this fork's Chinese pack; other upstream locales use English fallbacks
// for the three newly localized attribution labels.
import { readdirSync } from 'node:fs'
import zh from '../frontend/src/locales/zh.js'
const packs = await Promise.all(readdirSync(new URL('../frontend/src/locales/', import.meta.url))
  .filter(f => f.endsWith('.js')).map(async f => (await import('../frontend/src/locales/' + f)).default))
const keys = new Set(packs.flatMap(Object.keys))
const marks = s => [...s.matchAll(/\{\d+\}/g)].map(m => m[0]).sort().join(' ')
const errors = [...keys].filter(k => !zh[k]?.trim() || marks(k) !== marks(zh[k]))
if (errors.length) { console.error(errors); process.exit(1) }
console.log(`简体中文：${keys.size} 条文本完整，参数占位符一致。`)
